import "server-only";
import { daysBetween, noShowRisk, type NoShowRisk } from "@ecosaude/core/crm";
import { and, inArray, lt, schema, sql, type Tx } from "@ecosaude/db";

/**
 * Calcula o risco de falta de várias consultas de uma vez.
 * Busca o histórico (faltas e comparecimentos anteriores) de todos os
 * pacientes numa única consulta ao banco, em vez de uma por paciente.
 */
export async function riskFor(
  tx: Tx,
  appts: { id: string; contactId: string; startsAt: Date; createdAt: Date; status: string }[],
  now = new Date(),
): Promise<Map<string, NoShowRisk>> {
  const result = new Map<string, NoShowRisk>();
  const active = appts.filter((a) => (a.status === "agendado" || a.status === "confirmado") && a.startsAt > now);
  if (active.length === 0) return result;

  const contactIds = [...new Set(active.map((a) => a.contactId))];
  const history = await tx
    .select({
      contactId: schema.appointments.contactId,
      noShows: sql<number>`count(*) filter (where ${schema.appointments.status} = 'faltou')::int`,
      attended: sql<number>`count(*) filter (where ${schema.appointments.status} = 'compareceu')::int`,
    })
    .from(schema.appointments)
    .where(and(inArray(schema.appointments.contactId, contactIds), lt(schema.appointments.startsAt, now)))
    .groupBy(schema.appointments.contactId);
  const byContact = new Map(history.map((h) => [h.contactId, h]));

  for (const a of active) {
    const h = byContact.get(a.contactId);
    result.set(
      a.id,
      noShowRisk({
        pastNoShows: h?.noShows ?? 0,
        pastAttended: h?.attended ?? 0,
        confirmed: a.status === "confirmado",
        hoursUntil: (a.startsAt.getTime() - now.getTime()) / 3_600_000,
        leadTimeDays: Math.max(0, daysBetween(a.createdAt, a.startsAt)),
      }),
    );
  }
  return result;
}

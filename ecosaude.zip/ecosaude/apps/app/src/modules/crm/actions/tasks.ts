"use server";

import { todayIso } from "@ecosaude/core/crm";
import { taskSchema } from "@ecosaude/core/crm/validation";
import { flattenErrors } from "@ecosaude/core/validation";
import { and, eq, isNotNull, schema } from "@ecosaude/db";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorizeCrm } from "@/lib/auth/dal";
import { field, formValues, NOT_ALLOWED, toActionError, UserError, type ActionState } from "@/lib/server";
import { logEvent } from "../journey";
import { runCrm } from "../run";

/**
 * TAREFAS: criar/editar (com responsável), excluir e reabrir.
 * Concluir continua em contacts.ts (completeTaskAction).
 */

function refresh(contactId?: string | null) {
  revalidatePath("/hoje");
  revalidatePath("/crm/tarefas");
  if (contactId) revalidatePath(`/crm/contatos/${contactId}`);
}

export async function saveTaskAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("pacientes.editar");
  if (!ctx) return NOT_ALLOWED;
  const id = field(form, "id");
  const parsed = taskSchema.safeParse({
    contactId: field(form, "contactId"),
    title: field(form, "title"),
    dueDate: field(form, "dueDate") || todayIso(),
    assigneeId: field(form, "assigneeId"),
  });
  if (!parsed.success || (id && !z.uuid().safeParse(id).success)) {
    return { ok: false, errors: parsed.success ? {} : flattenErrors(parsed.error), values: formValues(form) };
  }
  const d = parsed.data;
  try {
    await runCrm(ctx, async (tx, scope) => {
      const assigneeId = d.assigneeId ?? scope.actorId;
      if (assigneeId) {
        // Responsável precisa ser da clínica e estar ativo (RLS limita à clínica)
        const [u] = await tx.select({ active: schema.clinicUsers.active }).from(schema.clinicUsers).where(eq(schema.clinicUsers.id, assigneeId));
        if (!u?.active) throw new UserError("Responsável não encontrado ou desativado.");
      }
      if (id) {
        const rows = await tx
          .update(schema.tasks)
          .set({ title: d.title, dueDate: d.dueDate, assigneeId, contactId: d.contactId ?? null })
          .where(eq(schema.tasks.id, id))
          .returning({ id: schema.tasks.id });
        if (!rows.length) throw new UserError("Tarefa não encontrada.");
      } else {
        await tx.insert(schema.tasks).values({ contactId: d.contactId ?? null, title: d.title, dueDate: d.dueDate, assigneeId, createdBy: scope.actorId });
      }
    });
  } catch (error) {
    return { ...toActionError(error), values: formValues(form) };
  }
  refresh(d.contactId);
  return { ok: true, message: id ? "Tarefa atualizada." : "Tarefa criada." };
}

export async function deleteTaskAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("pacientes.editar");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  const contactId = await runCrm(ctx, async (tx, scope) => {
    const [t] = await tx.delete(schema.tasks).where(eq(schema.tasks.id, id.data)).returning();
    if (t?.contactId) await logEvent(tx, { contactId: t.contactId, actorId: scope.actorId, type: "task_deleted", data: { title: t.title } });
    return t?.contactId ?? null;
  });
  refresh(contactId);
  return { ok: true, message: "Tarefa excluída." };
}

export async function reopenTaskAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("pacientes.ver");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  const contactId = await runCrm(ctx, async (tx) => {
    const [t] = await tx
      .update(schema.tasks)
      .set({ doneAt: null })
      .where(and(eq(schema.tasks.id, id.data), isNotNull(schema.tasks.doneAt)))
      .returning({ contactId: schema.tasks.contactId });
    return t?.contactId ?? null;
  });
  refresh(contactId);
  return { ok: true, message: "Tarefa reaberta." };
}

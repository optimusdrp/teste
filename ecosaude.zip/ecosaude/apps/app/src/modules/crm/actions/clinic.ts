"use server";

import { utcToZoned } from "@ecosaude/core/crm";
import { crmSettingsSchema, professionalSchema } from "@ecosaude/core/crm/validation";
import { flattenErrors } from "@ecosaude/core/validation";
import { and, eq, gt, inArray, schema } from "@ecosaude/db";
import { revalidatePath } from "next/cache";
import { authorizeCrm } from "@/lib/auth/dal";
import { field, formValues, NOT_ALLOWED, toActionError, UserError, type ActionState } from "@/lib/server";
import { logEvent } from "../journey";
import { runCrm } from "../run";

/**
 * AJUSTES DA CLÍNICA (gestão): profissionais com seus horários e as
 * preferências do CRM (confirmação automática).
 */

const toMin = (hhmm: string) => Number(hhmm.slice(0, 2)) * 60 + Number(hhmm.slice(3, 5));

/* ------------------------------- Profissionais ------------------------------ */

export async function saveProfessionalAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.clinica");
  if (!ctx) return NOT_ALLOWED;
  const parsed = professionalSchema.safeParse({
    id: field(form, "id"),
    name: field(form, "name"),
    specialty: field(form, "specialty"),
    color: field(form, "color"),
    slotMinutes: field(form, "slotMinutes"),
    workStart: field(form, "workStart"),
    workEnd: field(form, "workEnd"),
    breakStart: field(form, "breakStart"),
    breakEnd: field(form, "breakEnd"),
    workDays: form.getAll("workDays").map(String),
    userId: field(form, "userId"),
    active: form.get("active") === "on",
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const { id, ...d } = parsed.data;
  const values = {
    ...d,
    specialty: d.specialty ?? null,
    breakStart: d.breakStart ?? null,
    breakEnd: d.breakEnd ?? null,
    userId: d.userId ?? null,
  };

  let warning = "";
  try {
    await runCrm(ctx, async (tx, scope) => {
      if (!id) {
        const [created] = await tx.insert(schema.professionals).values(values).returning({ id: schema.professionals.id });
        await logEvent(tx, { actorId: scope.actorId, type: "professional_created", data: { professionalId: created!.id, nome: d.name } });
        return;
      }

      // Consultas futuras deste profissional: não podem "sumir" da agenda
      const future = await tx
        .select({ startsAt: schema.appointments.startsAt, endsAt: schema.appointments.endsAt })
        .from(schema.appointments)
        .where(
          and(
            eq(schema.appointments.professionalId, id),
            gt(schema.appointments.startsAt, new Date()),
            inArray(schema.appointments.status, ["agendado", "confirmado"]),
          ),
        );
      if (!d.active && future.length) {
        throw new UserError(`Há ${future.length} consulta(s) futura(s) com este profissional. Remarque ou cancele antes de desativar.`);
      }

      const rows = await tx.update(schema.professionals).set(values).where(eq(schema.professionals.id, id)).returning({ id: schema.professionals.id });
      if (rows.length === 0) throw new UserError("Profissional não encontrado.");
      await logEvent(tx, { actorId: scope.actorId, type: "professional_updated", data: { professionalId: id, nome: d.name } });

      // Mudou o horário? Avisa quais consultas já marcadas ficaram fora do novo expediente
      const outside = future.filter((a) => {
        const z = utcToZoned(a.startsAt);
        const start = z.minutes;
        const end = start + Math.round((a.endsAt.getTime() - a.startsAt.getTime()) / 60_000);
        const inBreak = d.breakStart && d.breakEnd ? start < toMin(d.breakEnd) && toMin(d.breakStart) < end : false;
        return !d.workDays.includes(z.weekday) || start < toMin(d.workStart) || end > toMin(d.workEnd) || inBreak;
      });
      if (outside.length) {
        warning = ` Atenção: ${outside.length} consulta(s) já marcada(s) ficaram fora do novo horário. Elas continuam valendo; remarque se precisar.`;
      }
    });
  } catch (error) {
    return { ...toActionError(error), values: formValues(form) };
  }
  revalidatePath("/configuracoes/profissionais");
  revalidatePath("/crm/agenda");
  revalidatePath("/", "layout");
  return { ok: true, message: (id ? "Profissional atualizado." : "Profissional cadastrado.") + warning };
}

/* --------------------------- Preferências do CRM ----------------------------- */

export async function saveCrmSettingsAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.clinica");
  if (!ctx) return NOT_ALLOWED;
  const parsed = crmSettingsSchema.safeParse({
    autoConfirm: form.get("autoConfirm") === "on",
    confirmHour: field(form, "confirmHour"),
    confirmDaysBefore: field(form, "confirmDaysBefore"),
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  await runCrm(ctx, async (tx, scope) => {
    // Uma linha por clínica: cria na primeira vez, atualiza depois
    await tx
      .insert(schema.crmSettings)
      .values(parsed.data)
      .onConflictDoUpdate({ target: schema.crmSettings.clinicId, set: { ...parsed.data, updatedAt: new Date() } });
    await logEvent(tx, { actorId: scope.actorId, type: "crm_settings_updated", data: parsed.data });
  });
  revalidatePath("/configuracoes/clinica");
  return { ok: true, message: "Preferências salvas." };
}

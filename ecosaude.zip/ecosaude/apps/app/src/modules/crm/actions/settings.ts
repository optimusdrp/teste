"use server";

import { temporaryPassword } from "@ecosaude/auth/crypto";
import { hasRealCredentials } from "@ecosaude/channels";
import { CHANNEL_MODES, CHANNELS, CRM_FEATURES } from "@ecosaude/core/crm";
import { clinicUserSchema, quickReplySchema, returnProtocolSchema } from "@ecosaude/core/crm/validation";
import { flattenErrors } from "@ecosaude/core/validation";
import { and, eq, ne, schema } from "@ecosaude/db";
import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { authorizeCrm } from "@/lib/auth/dal";
import { destroyUserSessions } from "@/lib/auth/session";
import { field, formValues, isUniqueViolation, NOT_ALLOWED, toActionError, UserError, type ActionState } from "@/lib/server";
import { logEvent } from "../journey";
import { runCrm } from "../run";

/**
 * AJUSTES DA CLÍNICA: respostas rápidas, protocolos de retorno, equipe e canais.
 * Tudo roda isolado na clínica de quem está logado (RLS no banco).
 */

/* ----------------------------- Respostas rápidas ---------------------------- */

export async function saveQuickReplyAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.respostas");
  if (!ctx) return NOT_ALLOWED;
  const parsed = quickReplySchema.safeParse({
    id: field(form, "id"),
    shortcut: field(form, "shortcut").replace(/^\//, ""),
    title: field(form, "title"),
    body: field(form, "body"),
    approvedTemplate: form.get("approvedTemplate") === "on",
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const { id, ...d } = parsed.data;
  try {
    await runCrm(ctx, async (tx) => {
      // Atalho repetido confundiria o menu "/"
      const [dup] = await tx
        .select({ id: schema.quickReplies.id })
        .from(schema.quickReplies)
        .where(and(eq(schema.quickReplies.shortcut, d.shortcut), id ? ne(schema.quickReplies.id, id) : undefined));
      if (dup) throw new UserError(`O atalho /${d.shortcut} já existe.`);
      if (id) await tx.update(schema.quickReplies).set(d).where(eq(schema.quickReplies.id, id));
      else await tx.insert(schema.quickReplies).values(d);
    });
  } catch (error) {
    return { ...toActionError(error), values: formValues(form) };
  }
  revalidatePath("/configuracoes/respostas");
  return { ok: true, message: id ? "Resposta atualizada." : "Resposta criada." };
}

export async function deleteQuickReplyAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.respostas");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  await runCrm(ctx, (tx) => tx.delete(schema.quickReplies).where(eq(schema.quickReplies.id, id.data)));
  revalidatePath("/configuracoes/respostas");
  return { ok: true, message: "Resposta excluída." };
}

/* ---------------------------- Protocolos de retorno -------------------------- */

export async function saveReturnProtocolAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("retornos.gerir", CRM_FEATURES.campaigns);
  if (!ctx) return NOT_ALLOWED;
  const parsed = returnProtocolSchema.safeParse({
    id: field(form, "id"),
    name: field(form, "name"),
    serviceMatch: field(form, "serviceMatch"),
    daysAfter: field(form, "daysAfter"),
    message: field(form, "message"),
    active: form.get("active") === "on",
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const { id, ...d } = parsed.data;
  const values = { ...d, serviceMatch: d.serviceMatch ?? null };
  await runCrm(ctx, (tx) =>
    id ? tx.update(schema.returnProtocols).set(values).where(eq(schema.returnProtocols.id, id)) : tx.insert(schema.returnProtocols).values(values),
  );
  revalidatePath("/crm/retornos");
  return { ok: true, message: id ? "Protocolo atualizado." : "Protocolo criado." };
}

/* ----------------------------------- Equipe ---------------------------------- */

/**
 * O gestor cadastra a equipe. A pessoa recebe uma SENHA TEMPORÁRIA (mostrada
 * uma única vez) e é obrigada a trocá-la no primeiro acesso.
 */
export async function createClinicUserAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.equipe");
  if (!ctx) return NOT_ALLOWED;
  const parsed = clinicUserSchema.safeParse({ name: field(form, "name"), email: field(form, "email").toLowerCase(), role: field(form, "role") });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const password = temporaryPassword();
  try {
    await runCrm(ctx, async (tx, scope) => {
      await tx.insert(schema.clinicUsers).values({ ...parsed.data, passwordHash: await bcrypt.hash(password, 12), mustChangePassword: true });
      await logEvent(tx, { actorId: scope.actorId, type: "user_created", data: { email: parsed.data.email, perfil: parsed.data.role } });
    });
  } catch (error) {
    // O e-mail é único em todas as clínicas (o login descobre a clínica pelo e-mail)
    if (isUniqueViolation(error)) return { ok: false, errors: { email: "Este e-mail já tem acesso ao EcoSaúde. Use outro." }, values: formValues(form) };
    return { ...toActionError(error), values: formValues(form) };
  }
  revalidatePath("/configuracoes/equipe");
  return { ok: true, message: `Acesso criado para ${parsed.data.name}.`, secret: password };
}

export async function resetClinicUserPasswordAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.equipe");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  if (id.data === ctx.user.id) return { ok: false, message: "Para a sua própria senha, use Minha conta." };
  const password = temporaryPassword();
  const found = await runCrm(ctx, async (tx, scope) => {
    // RLS: só encontra usuários da própria clínica
    const rows = await tx
      .update(schema.clinicUsers)
      .set({ passwordHash: await bcrypt.hash(password, 12), mustChangePassword: true, failedLogins: 0, lockedUntil: null })
      .where(eq(schema.clinicUsers.id, id.data))
      .returning({ id: schema.clinicUsers.id });
    if (rows.length) await logEvent(tx, { actorId: scope.actorId, type: "user_password_reset", data: { userId: id.data } });
    return rows.length > 0;
  });
  if (!found) return { ok: false, message: "Usuário não encontrado." };
  // Derruba as sessões abertas dessa pessoa (tabela de sessões fica fora do papel da clínica)
  await destroyUserSessions(id.data);
  revalidatePath("/configuracoes/equipe");
  return { ok: true, message: "Nova senha temporária gerada.", secret: password };
}

export async function toggleClinicUserAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.equipe");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  if (id.data === ctx.user.id) return { ok: false, message: "Você não pode desativar o próprio acesso." };
  const active = field(form, "active") === "true";
  try {
    await runCrm(ctx, async (tx, scope) => {
      if (!active) {
        // Nunca deixar a clínica sem nenhum gestor ativo
        const target = await tx.query.clinicUsers.findFirst({ where: eq(schema.clinicUsers.id, id.data), columns: { role: true } });
        if (target?.role === "gestor") {
          const others = await tx
            .select({ id: schema.clinicUsers.id })
            .from(schema.clinicUsers)
            .where(and(eq(schema.clinicUsers.role, "gestor"), eq(schema.clinicUsers.active, true), ne(schema.clinicUsers.id, id.data)));
          if (others.length === 0) throw new UserError("A clínica precisa de pelo menos um gestor ativo.");
        }
      }
      const rows = await tx.update(schema.clinicUsers).set({ active }).where(eq(schema.clinicUsers.id, id.data)).returning({ id: schema.clinicUsers.id });
      if (rows.length === 0) throw new UserError("Usuário não encontrado.");
      await logEvent(tx, { actorId: scope.actorId, type: active ? "user_enabled" : "user_disabled", data: { userId: id.data } });
    });
  } catch (error) {
    return toActionError(error);
  }
  if (!active) await destroyUserSessions(id.data);
  revalidatePath("/configuracoes/equipe");
  return { ok: true, message: active ? "Acesso reativado." : "Acesso desativado." };
}

/* ----------------------------------- Canais ---------------------------------- */

const channelSchema = z.object({
  channel: z.enum(CHANNELS),
  mode: z.enum(CHANNEL_MODES),
  active: z.boolean(),
  displayName: z.string().trim().max(80).optional().transform((v) => v || null),
  externalAccountId: z.string().trim().max(120).optional().transform((v) => v || null),
});

/**
 * Configura um canal. O modo REAL só é aceito quando o servidor tem a
 * credencial do canal e a clínica informou o identificador da conta
 * (número, página, bot). Sem isso, continua em simulação.
 */
export async function saveChannelAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.canais");
  if (!ctx) return NOT_ALLOWED;
  const parsed = channelSchema.safeParse({
    channel: field(form, "channel"),
    mode: field(form, "mode"),
    active: form.get("active") === "on",
    displayName: field(form, "displayName"),
    externalAccountId: field(form, "externalAccountId"),
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const d = parsed.data;
  if (d.mode === "real") {
    if (!hasRealCredentials(d.channel)) return { ok: false, message: "O servidor ainda não tem a credencial deste canal. Veja o passo a passo abaixo." };
    if (!d.externalAccountId) return { ok: false, errors: { externalAccountId: "Informe o identificador da conta para o modo real." } };
  }
  try {
    await runCrm(ctx, async (tx, scope) => {
      await tx
        .insert(schema.channelConnections)
        .values(d)
        .onConflictDoUpdate({ target: [schema.channelConnections.clinicId, schema.channelConnections.channel], set: { ...d, updatedAt: new Date() } });
      await logEvent(tx, { actorId: scope.actorId, type: "channel_updated", data: { canal: d.channel, modo: d.mode, ativo: d.active } });
    });
  } catch (error) {
    if (isUniqueViolation(error)) return { ok: false, errors: { externalAccountId: "Esta conta já está ligada a outra clínica." } };
    return toActionError(error);
  }
  revalidatePath("/configuracoes/canais");
  revalidatePath("/", "layout");
  return { ok: true, message: "Canal salvo." };
}

/** Editar nome e perfil de alguém da equipe (a clínica nunca fica sem gestor ativo). */
export async function updateClinicUserAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.equipe");
  if (!ctx) return NOT_ALLOWED;
  const parsed = z
    .object({ id: z.uuid(), name: z.string().trim().min(2, "Informe o nome.").max(120), role: z.enum(["gestor", "recepcao", "profissional"]) })
    .safeParse({ id: field(form, "id"), name: field(form, "name"), role: field(form, "role") });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const d = parsed.data;
  if (d.id === ctx.user.id && d.role !== ctx.user.role) return { ok: false, message: "Você não pode mudar o próprio perfil. Peça a outro gestor." };
  try {
    await runCrm(ctx, async (tx, scope) => {
      const target = await tx.query.clinicUsers.findFirst({ where: eq(schema.clinicUsers.id, d.id), columns: { role: true, active: true } });
      if (!target) throw new UserError("Usuário não encontrado.");
      if (target.role === "gestor" && d.role !== "gestor" && target.active) {
        const others = await tx
          .select({ id: schema.clinicUsers.id })
          .from(schema.clinicUsers)
          .where(and(eq(schema.clinicUsers.role, "gestor"), eq(schema.clinicUsers.active, true), ne(schema.clinicUsers.id, d.id)));
        if (others.length === 0) throw new UserError("A clínica precisa de pelo menos um gestor ativo.");
      }
      await tx.update(schema.clinicUsers).set({ name: d.name, role: d.role }).where(eq(schema.clinicUsers.id, d.id));
      await logEvent(tx, { actorId: scope.actorId, type: "user_updated", data: { userId: d.id, perfil: d.role } });
    });
  } catch (error) {
    return { ...toActionError(error), values: formValues(form) };
  }
  // Perfil mudou: as sessões abertas passam a valer com o perfil novo na próxima requisição
  revalidatePath("/configuracoes/equipe");
  return { ok: true, message: "Dados atualizados." };
}

/**
 * Perdeu o celular da verificação em duas etapas? O gestor desliga a 2FA da
 * pessoa, que entra só com a senha e pode ativar de novo em Minha conta.
 */
export async function resetClinicUserTwoFactorAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("config.equipe");
  if (!ctx) return NOT_ALLOWED;
  const id = z.uuid().safeParse(field(form, "id"));
  if (!id.success) return { ok: false, message: "Inválido." };
  if (id.data === ctx.user.id) return { ok: false, message: "Para a sua própria conta, use Minha conta." };
  const found = await runCrm(ctx, async (tx, scope) => {
    const rows = await tx
      .update(schema.clinicUsers)
      .set({ totpEnabled: false, totpSecretEnc: null, totpLastStep: null })
      .where(eq(schema.clinicUsers.id, id.data))
      .returning({ id: schema.clinicUsers.id });
    if (rows.length) await logEvent(tx, { actorId: scope.actorId, type: "user_2fa_reset", data: { userId: id.data } });
    return rows.length > 0;
  });
  if (!found) return { ok: false, message: "Usuário não encontrado." };
  await destroyUserSessions(id.data);
  revalidatePath("/configuracoes/equipe");
  return { ok: true, message: "Verificação em duas etapas desligada. A pessoa entra só com a senha e pode ativar de novo." };
}

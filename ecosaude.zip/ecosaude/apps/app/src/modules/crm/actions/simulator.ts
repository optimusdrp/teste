"use server";

import { parseWebhook, samplePayload } from "@ecosaude/channels";
import { simulatorMessageSchema } from "@ecosaude/core/crm/validation";
import { flattenErrors } from "@ecosaude/core/validation";
import { and, eq, schema } from "@ecosaude/db";
import { revalidatePath } from "next/cache";
import { authorizeCrm } from "@/lib/auth/dal";
import { field, formValues, NOT_ALLOWED, type ActionState } from "@/lib/server";
import { ingestInbound } from "../ingest";
import { runCrm } from "../run";

/**
 * SIMULADOR: envia uma mensagem "como se fosse o paciente".
 *
 * Importante: a mensagem simulada é montada no FORMATO OFICIAL do provedor
 * (o mesmo JSON que a Meta/Telegram enviam ao webhook) e passa pelo MESMO
 * leitor (parseWebhook) e pela MESMA entrada (ingestInbound) da integração
 * real. Quando o canal real for ligado, só muda quem chama esse caminho.
 */
export async function simulateInboundAction(_prev: ActionState, form: FormData): Promise<ActionState> {
  const ctx = await authorizeCrm("conversas.ver");
  if (!ctx) return NOT_ALLOWED;

  const parsed = simulatorMessageSchema.safeParse({
    channel: field(form, "channel"),
    externalId: field(form, "externalId"),
    name: field(form, "name") || undefined,
    text: field(form, "text"),
  });
  if (!parsed.success) return { ok: false, errors: flattenErrors(parsed.error), values: formValues(form) };
  const { channel, name, text } = parsed.data;
  // WhatsApp identifica pelo telefone (só números)
  const externalId = channel === "whatsapp" ? parsed.data.externalId.replace(/\D/g, "") : parsed.data.externalId.replace(/^@/, "");
  if (channel === "whatsapp" && externalId.length < 12) {
    return { ok: false, errors: { externalId: "Use o telefone com DDI e DDD, ex.: 5551999990000." }, values: formValues(form) };
  }

  const result = await runCrm(
    ctx,
    async (tx, scope) => {
      const [conn] = await tx
        .select()
        .from(schema.channelConnections)
        .where(and(eq(schema.channelConnections.channel, channel), eq(schema.channelConnections.mode, "simulacao")));
      if (!conn) return null;
      const accountId = conn.externalAccountId ?? `sim-${channel}`;
      const payload = samplePayload(channel, { accountId, from: externalId, name, text });
      const { messages } = parseWebhook(channel, payload, accountId);
      const message = messages[0];
      if (!message) return null;
      return ingestInbound(tx, { ...scope, actorId: null }, message);
    },
    { dispatch: true },
  );

  if (!result) return { ok: false, message: "Este canal não está em modo simulação.", values: formValues(form) };
  revalidatePath("/crm/conversas");
  revalidatePath(`/crm/conversas/${result.conversationId}`);
  revalidatePath("/hoje");
  revalidatePath("/crm/agenda");
  revalidatePath("/crm/jornada");
  return {
    ok: true,
    message: result.automation ? `Mensagem recebida e tratada automaticamente (${result.automation.replace("_", " ")}).` : "Mensagem recebida pela clínica.",
    data: { conversationId: result.conversationId, automation: result.automation },
  };
}

import "server-only";
import { withTenant, type Tx } from "@ecosaude/db";
import type { CrmContext } from "@/lib/auth/dal";
import { dispatchQueued } from "./messaging";
import { scopeFrom, type CrmScope } from "./scope";

/**
 * Executa uma regra do CRM numa transação isolada na clínica e, ao final,
 * despacha as mensagens que ela colocou na fila.
 *
 * O despacho acontece DEPOIS do commit: se algo falhar no meio da regra,
 * nenhuma mensagem sai (tudo ou nada).
 */
export async function runCrm<T>(ctx: CrmContext, fn: (tx: Tx, scope: CrmScope) => Promise<T>, opts: { dispatch?: boolean } = {}): Promise<T> {
  const scope = scopeFrom(ctx);
  const result = await withTenant(scope.clinicId, (tx) => fn(tx, scope));
  if (opts.dispatch) await dispatchQueued(scope.clinicId);
  return result;
}

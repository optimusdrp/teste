import { timingSafeEqual } from "node:crypto";
import { withTenant } from "@ecosaude/db";
import { NextResponse, type NextRequest } from "next/server";
import { recalcReactivation } from "@/modules/crm/journey";
import { dispatchQueued } from "@/modules/crm/messaging";
import { expireOffers, runAutoConfirmations } from "@/modules/crm/scheduling";
import { crmClinicIds, systemScope } from "@/modules/crm/system";

/**
 * ROTINA AGENDADA (Vercel Cron, ver vercel.json)
 *   - reenvia mensagens que ficaram na fila (erro temporário do provedor)
 *   - expira ofertas da lista de espera sem resposta
 *   - move para "Para reativar" quem passou muito tempo sem voltar
 *   - pede confirmação automática das consultas (conforme Ajustes > Clínica)
 *
 * Protegida por CRON_SECRET: a Vercel envia "Authorization: Bearer <CRON_SECRET>".
 */
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

function authorized(req: NextRequest): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const got = Buffer.from(req.headers.get("authorization") ?? "");
  const want = Buffer.from(`Bearer ${secret}`);
  return got.length === want.length && timingSafeEqual(got, want);
}

export async function GET(req: NextRequest) {
  if (!authorized(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const report: Record<string, { sent: number; failed: number; reactivated: number; confirmations: number } | { error: string }> = {};
  for (const clinicId of await crmClinicIds()) {
    try {
      const scope = await systemScope(clinicId);
      if (!scope) continue;
      const { reactivated, confirmations } = await withTenant(clinicId, async (tx) => {
        await expireOffers(tx);
        const reactivated = await recalcReactivation(tx);
        const auto = await runAutoConfirmations(tx, scope);
        return { reactivated, confirmations: auto.sent };
      });
      // Envia tudo o que ficou na fila (inclusive os pedidos de confirmação de agora)
      const { sent, failed } = await dispatchQueued(clinicId);
      report[clinicId] = { sent, failed, reactivated, confirmations };
    } catch (error) {
      // Uma clínica com problema não impede as outras
      console.error("[cron]", clinicId, error);
      report[clinicId] = { error: (error as Error).message };
    }
  }
  return NextResponse.json({ ok: true, clinics: report });
}

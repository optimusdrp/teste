import { withTenant } from "@ecosaude/db";
import { NextResponse } from "next/server";
import { apiContext, isResponse } from "@/lib/api";
import { logEvent } from "@/modules/crm/journey";
import { exportPatientData } from "@/modules/crm/patient";

/**
 * GET /api/contatos/<id>/exportar
 * LGPD, art. 18 (acesso e portabilidade): baixa um JSON com os dados do
 * paciente. A exportação fica registrada na linha do tempo (quem e quando).
 */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await apiContext("pacientes.editar");
  if (isResponse(ctx)) return ctx;
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return NextResponse.json({ error: "Inválido." }, { status: 400 });

  const data = await withTenant(ctx.user.clinicId, async (tx) => {
    const d = await exportPatientData(tx, id);
    if (d) await logEvent(tx, { contactId: id, actorId: ctx.user.id, type: "data_export" });
    return d;
  });
  if (!data) return NextResponse.json({ error: "Não encontrado." }, { status: 404 });

  const slug = data.titular.nome.normalize("NFD").replace(/[^\w\s-]/g, "").trim().replace(/\s+/g, "-").toLowerCase();
  return new NextResponse(JSON.stringify(data, null, 2), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="dados-${slug}.json"`,
      "cache-control": "no-store",
    },
  });
}

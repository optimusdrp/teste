import { addDaysIso, todayIso, zonedToUtc } from "@ecosaude/core/crm";
import { and, asc, desc, eq, gte, inSequence, isNotNull, isNull, lt, schema, withTenant, type SQL } from "@ecosaude/db";
import type { Metadata } from "next";
import Link from "next/link";
import { TaskButton } from "@/components/crm/TaskTools";
import { ActionButton, PatientLink } from "@/components/crm/widgets";
import { Badge, EmptyState, PageHeader } from "@/components/ui/server";
import { cn } from "@/components/ui/styles";
import { requireCrm } from "@/lib/auth/dal";
import { now } from "@/lib/clock";
import { completeTaskAction } from "@/modules/crm/actions/contacts";
import { deleteTaskAction, reopenTaskAction } from "@/modules/crm/actions/tasks";

export const metadata: Metadata = { title: "Tarefas" };
export const dynamic = "force-dynamic";

const VIEWS = { minhas: "Minhas", todas: "Todas", atrasadas: "Atrasadas", concluidas: "Concluídas" } as const;
type View = keyof typeof VIEWS;

/**
 * TAREFAS DA EQUIPE
 * Lembretes com prazo e responsável: "ligar para saber do exame",
 * "remarcar quem faltou" (criada sozinha), "conferir convênio"...
 */
export default async function TasksPage({ searchParams }: { searchParams: Promise<{ ver?: string }> }) {
  const ctx = await requireCrm("pacientes.ver");
  const sp = await searchParams;
  const view: View = sp.ver && sp.ver in VIEWS ? (sp.ver as View) : "minhas";
  const today = todayIso(now());
  const t = schema.tasks;

  const where: SQL[] = [];
  if (view === "concluidas") where.push(isNotNull(t.doneAt), gte(t.doneAt, zonedToUtc(addDaysIso(today, -30), "00:00")));
  else where.push(isNull(t.doneAt));
  if (view === "minhas") where.push(eq(t.assigneeId, ctx.user.id));
  if (view === "atrasadas") where.push(lt(t.dueDate, today));

  const [tasks, team] = await withTenant(ctx.user.clinicId, (tx) =>
    inSequence([
      () =>
        tx.query.tasks.findMany({
          where: and(...where),
          with: { contact: { columns: { id: true, name: true } }, assignee: { columns: { id: true, name: true } } },
          orderBy: view === "concluidas" ? desc(t.doneAt) : [asc(t.dueDate), asc(t.createdAt)],
          limit: 200,
        }),
      () =>
        tx
          .select({ id: schema.clinicUsers.id, name: schema.clinicUsers.name })
          .from(schema.clinicUsers)
          .where(eq(schema.clinicUsers.active, true))
          .orderBy(asc(schema.clinicUsers.name)),
    ]),
  );
  const canEdit = ctx.can("pacientes.editar");
  const groups =
    view === "concluidas"
      ? [{ title: "Concluídas nos últimos 30 dias", items: tasks }]
      : [
          { title: "Atrasadas", items: tasks.filter((x) => x.dueDate < today) },
          { title: "Hoje", items: tasks.filter((x) => x.dueDate === today) },
          { title: "Próximas", items: tasks.filter((x) => x.dueDate > today) },
        ];

  return (
    <>
      <PageHeader title="Tarefas" description="Lembretes da equipe, com prazo e responsável." actions={canEdit ? <TaskButton team={team} today={today} /> : null} />
      <nav aria-label="Filtrar tarefas" className="-mx-3 mb-4 overflow-x-auto px-3 sm:mx-0 sm:px-0">
        <ul className="flex w-max gap-1.5">
          {(Object.keys(VIEWS) as View[]).map((v) => (
            <li key={v}>
              <Link
                href={v === "minhas" ? "/crm/tarefas" : `/crm/tarefas?ver=${v}`}
                aria-current={view === v ? "page" : undefined}
                className={cn("inline-flex min-h-10 items-center rounded-full px-3.5 text-sm font-semibold ring-1", view === v ? "bg-ink text-white ring-ink" : "bg-paper ring-line")}
              >
                {VIEWS[v]}
              </Link>
            </li>
          ))}
        </ul>
      </nav>

      {tasks.length === 0 ? (
        <EmptyState title="Nenhuma tarefa aqui">{view === "minhas" ? "Você está em dia." : "Nada neste filtro."}</EmptyState>
      ) : (
        <div className="space-y-5">
          {groups
            .filter((g) => g.items.length)
            .map((g) => (
              <section key={g.title} aria-label={g.title}>
                <h2 className={cn("mb-2 text-sm font-bold", g.title === "Atrasadas" && "text-alert")}>
                  {g.title} <span className="font-normal text-ink-soft">({g.items.length})</span>
                </h2>
                <ul className="divide-y divide-line rounded-2xl bg-paper ring-1 ring-line">
                  {g.items.map((task) => (
                    <li key={task.id} className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:gap-3">
                      <div className="min-w-0 flex-1">
                        <p className={cn("font-semibold", task.doneAt && "text-ink-soft line-through")}>{task.title}</p>
                        <p className="flex flex-wrap items-center gap-x-2 text-sm text-ink-soft">
                          <span>{task.dueDate === today ? "hoje" : task.dueDate.split("-").reverse().join("/")}</span>
                          {task.contact ? <PatientLink id={task.contact.id} name={task.contact.name} className="text-sm" /> : null}
                          <span>{task.assignee ? `com ${task.assignee.name}` : "sem responsável"}</span>
                          {task.kind === "falta" ? <Badge tone="alert">falta</Badge> : null}
                          {task.kind === "nps_baixo" ? <Badge tone="warning">satisfação baixa</Badge> : null}
                        </p>
                      </div>
                      <div className="flex flex-wrap items-center gap-1">
                        {task.doneAt ? (
                          <ActionButton action={reopenTaskAction} fields={{ id: task.id }} label="Reabrir" variant="ghost" pendingText="..." />
                        ) : (
                          <ActionButton action={completeTaskAction} fields={{ id: task.id }} label="Feito" variant="secondary" pendingText="..." />
                        )}
                        {canEdit && !task.doneAt ? (
                          <TaskButton
                            team={team}
                            today={today}
                            initial={{ id: task.id, title: task.title, dueDate: task.dueDate, assigneeId: task.assigneeId ?? "", contact: task.contact }}
                          />
                        ) : null}
                        {canEdit ? (
                          <ActionButton action={deleteTaskAction} fields={{ id: task.id }} label="Excluir" variant="ghost" pendingText="..." confirmText="Excluir esta tarefa?" />
                        ) : null}
                      </div>
                    </li>
                  ))}
                </ul>
              </section>
            ))}
        </div>
      )}
    </>
  );
}

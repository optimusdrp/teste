import { messagingWindow } from "@ecosaude/channels";
import {
  CRM_FEATURES,
  firstName,
  formatDayShort,
  formatTime,
  formatWhen,
  INTENT_LABEL,
  suggestReplies,
  URGENCY_GUIDANCE,
  type Channel,
  type Intent,
} from "@ecosaude/core/crm";
import { asc, eq, inSequence, schema, withTenant } from "@ecosaude/db";
import { notFound } from "next/navigation";
import { InboxLayout } from "@/components/crm/inbox/InboxLayout";
import type { InboxCounts, InboxItem, ThreadData } from "@/components/crm/inbox/types";
import { LockedFeature } from "@/components/ui/server";
import type { CrmContext } from "@/lib/auth/dal";
import { now as clockNow } from "@/lib/clock";
import { describeEvent } from "@/modules/crm/format";
import { INBOX_PAGE, inboxCounts, listConversations, loadThread, quickReplies, threadContext, type InboxFilter, type InboxSort } from "@/modules/crm/inbox";

/**
 * MESA DE MENSAGENS (omnichannel), parte do SERVIDOR
 *
 * Busca a lista, os números, a conversa aberta e o contexto do paciente numa
 * única transação isolada pela clínica, converte datas em números e entrega
 * ao quadro interativo (InboxLayout), que cuida de: seleção e ações em lote,
 * atalhos de teclado, busca dentro da conversa, rascunhos, painel lateral com
 * abas e as preferências de cada pessoa.
 *
 * O ASSISTENTE não é IA externa: usa regras locais para mostrar a intenção do
 * paciente, respostas sugeridas com horários livres reais, alerta de urgência
 * e o estado da janela de 24h do canal.
 */
export async function Inbox({
  ctx,
  selectedId,
  filter,
  channel,
  q,
  limit,
  sort,
}: {
  ctx: CrmContext;
  selectedId?: string;
  filter: InboxFilter;
  channel?: Channel;
  q?: string;
  limit: number;
  sort: InboxSort;
}) {
  if (!ctx.has(CRM_FEATURES.inbox)) {
    return (
      <LockedFeature title="Caixa de entrada omnichannel">
        Todas as conversas de WhatsApp, Telegram, Instagram e Messenger num só lugar, com fila por tempo de espera.
      </LockedFeature>
    );
  }

  const current = clockNow();
  const nowMs = current.getTime();
  const data = await withTenant(ctx.user.clinicId, async (tx) => {
    const [page, counts, thread, replies, team] = await inSequence([
      () => listConversations(tx, { filter, channel, userId: ctx.user.id, q, limit, sort }),
      () => inboxCounts(tx, ctx.user.id),
      () => (selectedId ? loadThread(tx, selectedId) : Promise.resolve(null)),
      () => quickReplies(tx),
      // Quem pode receber conversas transferidas
      () =>
        tx
          .select({ id: schema.clinicUsers.id, name: schema.clinicUsers.name })
          .from(schema.clinicUsers)
          .where(eq(schema.clinicUsers.active, true))
          .orderBy(asc(schema.clinicUsers.name)),
    ]);
    const context = thread ? await threadContext(tx, thread.conversation.contactId) : null;
    return { page, counts, thread, replies, team, context };
  });
  if (selectedId && !data.thread) notFound();

  /* ------------------------------ Lista ------------------------------ */
  const items: InboxItem[] = data.page.items.map((c) => ({
    id: c.id,
    contactId: c.contact.id,
    contactName: c.contact.name,
    channel: c.channel,
    status: c.status,
    preview: c.lastMessagePreview,
    lastMessageMs: c.lastMessageAt?.getTime() ?? null,
    waitingSinceMs: c.status === "aberta" && c.awaitingReplySince ? c.awaitingReplySince.getTime() : null,
    snoozedUntilMs: c.snoozedUntil && c.snoozedUntil.getTime() > nowMs ? c.snoozedUntil.getTime() : null,
    unread: c.unreadCount,
    urgent: c.urgent,
    intentLabel: c.intent ? (INTENT_LABEL[c.intent as Intent] ?? c.intent) : null,
    assigneeId: c.assignee?.id ?? null,
    assigneeName: c.assignee?.name.split(" ")[0] ?? null,
  }));
  const counts: InboxCounts = { ...data.counts, maisAntigaMs: data.counts.maisAntiga?.getTime() ?? null };

  /* ----------------------------- Conversa ----------------------------- */
  let thread: ThreadData | null = null;
  if (data.thread && data.context) {
    const { conversation: conv, messages } = data.thread;
    const contact = conv.contact;
    const win = messagingWindow(conv.channel, conv.lastInboundAt, current);
    const intent = conv.intent as Intent | null;
    thread = {
      id: conv.id,
      channel: conv.channel,
      status: conv.status,
      urgent: conv.urgent,
      urgentGuidance: conv.urgent ? URGENCY_GUIDANCE[(conv.urgentKind as "clinica" | "emocional") ?? "clinica"] : null,
      unread: conv.unreadCount,
      assigneeId: conv.assignee?.id ?? null,
      intent,
      intentLabel: intent ? INTENT_LABEL[intent] : null,
      contact: {
        id: contact.id,
        name: contact.name,
        phone: contact.phone,
        email: contact.email,
        stage: contact.stage,
        tags: contact.tags,
        source: contact.source,
        optedOut: !!contact.optedOutAt,
        consentMarketing: contact.consentMarketing,
        lastVisit: contact.lastVisitAt ? formatDayShort(contact.lastVisitAt) : null,
        since: formatDayShort(contact.createdAt),
      },
      messages: messages.map((m) => ({
        id: m.id,
        direction: m.direction,
        body: m.body,
        status: m.status,
        createdMs: m.createdAt.getTime(),
        dayLabel: formatDayShort(m.createdAt),
        time: formatTime(m.createdAt),
        authorName: m.author?.name.split(" ")[0] ?? null,
        auto: m.direction === "out" && !m.authorId,
        handledBy: ((m.meta as { handledBy?: string } | null)?.handledBy ?? null)?.replace(/_/g, " ") ?? null,
        error: m.error,
      })),
      otherChannels: data.thread.otherChannels,
      next: data.thread.next
        ? { label: formatWhen(data.thread.next.startsAt, current), professional: data.thread.next.professional.name, status: data.thread.next.status }
        : null,
      slots: data.thread.slots,
      suggestionPro: data.thread.suggestionPro?.name ?? null,
      suggestions: suggestReplies(intent, { firstName: firstName(contact.name), slots: data.thread.slots, clinicName: ctx.user.clinicName }),
      window: {
        open: win.open,
        closesAtMs: win.closesAt?.getTime() ?? null,
        closesLabel: win.closesAt ? `${formatDayShort(win.closesAt)} às ${formatTime(win.closesAt)}` : null,
        unlimited: win.open && !win.closesAt,
      },
      stats: data.context.stats,
      events: data.context.events.map((e) => ({ id: e.id, text: describeEvent(e.type, e.data, current), when: formatWhen(e.createdAt, current) })),
    };
  }

  return (
    <InboxLayout
      items={items}
      hasMore={data.page.hasMore}
      counts={counts}
      thread={thread}
      selectedId={selectedId ?? null}
      filter={filter}
      channel={channel ?? null}
      q={q ?? ""}
      sort={sort}
      pages={Math.round(limit / INBOX_PAGE)}
      serverNowMs={nowMs}
      userId={ctx.user.id}
      team={data.team}
      canReply={ctx.can("conversas.responder")}
      canSchedule={ctx.can("agenda.editar")}
      quickReplies={data.replies.map((r) => ({ id: r.id, shortcut: r.shortcut, title: r.title, body: r.body, approvedTemplate: r.approvedTemplate }))}
      vars={thread ? { nome: thread.contact.name, primeiro_nome: firstName(thread.contact.name), clinica: ctx.user.clinicName } : null}
    />
  );
}

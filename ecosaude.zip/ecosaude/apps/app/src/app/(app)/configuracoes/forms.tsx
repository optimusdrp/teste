"use client";

import { CHANNEL_LABEL, CLINIC_ROLE_LABEL, CLINIC_ROLES, type Channel, type ChannelMode } from "@ecosaude/core/crm";
import { Copy, Pencil, Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import { useActionState, useEffect, useEffectEvent, useState } from "react";
import { CheckboxField, Dialog, Field, FormMessage, SelectField, SubmitButton, TextareaField } from "@/components/ui";
import { buttonStyles } from "@/components/ui/styles";
import type { ActionState } from "@/lib/server";
import {
  createClinicUserAction,
  deleteQuickReplyAction,
  resetClinicUserPasswordAction,
  resetClinicUserTwoFactorAction,
  saveChannelAction,
  saveQuickReplyAction,
  toggleClinicUserAction,
  updateClinicUserAction,
} from "@/modules/crm/actions/settings";
import { saveCrmSettingsAction, saveProfessionalAction } from "@/modules/crm/actions/clinic";

/** Formulários dos Ajustes (rodam no navegador e chamam server actions). */

function useRefreshOnOk(state: ActionState) {
  const router = useRouter();
  useEffect(() => {
    if (state.ok) router.refresh();
  }, [state, router]);
}

/* ----------------------------- Senha temporária ----------------------------- */

/** Mostra a senha temporária UMA vez, com botão de copiar. */
function TempPassword({ secret }: { secret: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="rounded-xl bg-erp-tint p-3 text-sm">
      <p className="font-semibold">Senha temporária (aparece só agora):</p>
      <div className="mt-1 flex items-center gap-2">
        <code className="min-w-0 flex-1 rounded-lg bg-paper px-3 py-2 text-base break-all ring-1 ring-line" data-testid="temp-password">
          {secret}
        </code>
        <button
          type="button"
          onClick={() => navigator.clipboard?.writeText(secret).then(() => setCopied(true))}
          className={buttonStyles("secondary")}
          aria-label="Copiar senha"
        >
          <Copy className="size-4" aria-hidden /> {copied ? "Copiada" : "Copiar"}
        </button>
      </div>
      <p className="mt-1 text-xs">Entregue pessoalmente. No primeiro acesso a pessoa cria a própria senha.</p>
    </div>
  );
}

/* ------------------------------ Respostas rápidas ----------------------------- */

export interface QuickReplyValues {
  id?: string;
  shortcut: string;
  title: string;
  body: string;
  approvedTemplate: boolean;
}

export function QuickReplyButton({ initial }: { initial?: QuickReplyValues }) {
  const [open, setOpen] = useState(false);
  const [state, action] = useActionState(saveQuickReplyAction, {});
  const [handled, setHandled] = useState(state);
  if (state !== handled) {
    setHandled(state);
    if (state.ok) setOpen(false);
  }
  useRefreshOnOk(state);
  const p = initial?.id ?? "new";
  const val = (k: keyof QuickReplyValues) => state.values?.[k] ?? String(initial?.[k] ?? "");

  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={buttonStyles(initial ? "ghost" : "primary")} aria-label={initial ? `Editar /${initial.shortcut}` : undefined}>
        {initial ? <Pencil className="size-4" aria-hidden /> : <Plus className="size-4" aria-hidden />}
        {initial ? "Editar" : "Nova resposta"}
      </button>
      <Dialog open={open} onClose={() => setOpen(false)} title={initial ? `Editar /${initial.shortcut}` : "Nova resposta rápida"} description="Na conversa, digite / e o atalho para inserir o texto.">
        <form action={action} className="space-y-4">
          <FormMessage state={state} />
          {initial?.id ? <input type="hidden" name="id" value={initial.id} /> : null}
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Atalho" name="shortcut" id={`qr-sc-${p}`} placeholder="horarios" defaultValue={val("shortcut")} error={state.errors?.shortcut} hint="Sem a barra. Ex.: horarios" />
            <Field label="Título" name="title" id={`qr-t-${p}`} placeholder="Horários de atendimento" defaultValue={val("title")} error={state.errors?.title} />
          </div>
          <TextareaField
            label="Texto"
            name="body"
            id={`qr-b-${p}`}
            rows={5}
            defaultValue={val("body")}
            error={state.errors?.body}
            hint="Variáveis: {{primeiro_nome}}, {{nome}}, {{clinica}}, {{data}}, {{hora}}, {{profissional}}."
          />
          <CheckboxField
            name="approvedTemplate"
            defaultChecked={state.values ? state.values.approvedTemplate === "on" : (initial?.approvedTemplate ?? false)}
            label="Modelo aprovado pela Meta"
            hint="Só modelos aprovados podem ser enviados no WhatsApp/Instagram/Messenger depois de 24h sem resposta do paciente."
          />
          <SubmitButton>Salvar</SubmitButton>
        </form>
      </Dialog>
    </>
  );
}

export function DeleteQuickReply({ id, shortcut }: { id: string; shortcut: string }) {
  const [state, action] = useActionState(deleteQuickReplyAction, {});
  useRefreshOnOk(state);
  return (
    <form
      action={action}
      onSubmit={(e) => {
        if (!window.confirm(`Excluir a resposta /${shortcut}?`)) e.preventDefault();
      }}
    >
      <input type="hidden" name="id" value={id} />
      <SubmitButton variant="ghost" pendingText="...">
        Excluir
      </SubmitButton>
    </form>
  );
}

/* ----------------------------------- Equipe ----------------------------------- */

export function NewUserButton() {
  const [open, setOpen] = useState(false);
  // Chave nova a cada abertura: o formulário (e a senha mostrada) começam do zero
  const [formKey, setFormKey] = useState(0);
  return (
    <>
      <button
        type="button"
        onClick={() => {
          setFormKey((k) => k + 1);
          setOpen(true);
        }}
        className={buttonStyles("primary")}
      >
        <Plus className="size-4" aria-hidden /> Novo acesso
      </button>
      <Dialog open={open} onClose={() => setOpen(false)} title="Novo acesso" description="A pessoa entra com o e-mail e a senha temporária e cria a própria senha.">
        <NewUserForm key={formKey} onClose={() => setOpen(false)} />
      </Dialog>
    </>
  );
}

function NewUserForm({ onClose }: { onClose: () => void }) {
  const [state, action] = useActionState(createClinicUserAction, {});
  useRefreshOnOk(state);
  if (state.ok && state.secret) {
    return (
      <div className="space-y-3">
        <FormMessage state={state} />
        <TempPassword secret={state.secret} />
        <button type="button" onClick={onClose} className={buttonStyles("secondary")}>
          Fechar
        </button>
      </div>
    );
  }
  return (
    <form action={action} className="space-y-4">
      <FormMessage state={state} />
      <Field label="Nome" name="name" id="nu-name" defaultValue={state.values?.name} error={state.errors?.name} />
      <Field label="E-mail" name="email" id="nu-email" type="email" defaultValue={state.values?.email} error={state.errors?.email} />
      <SelectField label="Perfil" name="role" id="nu-role" defaultValue={state.values?.role ?? "recepcao"}>
        {CLINIC_ROLES.map((r) => (
          <option key={r} value={r}>
            {CLINIC_ROLE_LABEL[r]}
          </option>
        ))}
      </SelectField>
      <ul className="list-disc space-y-0.5 pl-5 text-xs text-ink-soft">
        <li>Gestão: tudo, inclusive equipe e canais.</li>
        <li>Recepção: conversas, agenda, pacientes, retornos e respostas rápidas.</li>
        <li>Profissional: vê conversas e pacientes; mexe só na agenda.</li>
      </ul>
      <SubmitButton pendingText="Criando...">Criar acesso</SubmitButton>
    </form>
  );
}

export function UserActions({
  id,
  name,
  active,
  role,
  totpEnabled,
}: {
  id: string;
  name: string;
  active: boolean;
  role: string;
  totpEnabled: boolean;
}) {
  const [reset, resetAction] = useActionState(resetClinicUserPasswordAction, {});
  const [toggle, toggleAction] = useActionState(toggleClinicUserAction, {});
  const [twoFactor, twoFactorAction] = useActionState(resetClinicUserTwoFactorAction, {});
  const [editOpen, setEditOpen] = useState(false);
  const [editKey, setEditKey] = useState(0);
  useRefreshOnOk(toggle);
  useRefreshOnOk(twoFactor);
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-1">
        <button
          type="button"
          onClick={() => {
            setEditKey((k) => k + 1);
            setEditOpen(true);
          }}
          className={buttonStyles("ghost")}
        >
          Editar
        </button>
        <form
          action={resetAction}
          onSubmit={(e) => {
            if (!window.confirm(`Gerar nova senha temporária para ${name}? A pessoa será desconectada.`)) e.preventDefault();
          }}
        >
          <input type="hidden" name="id" value={id} />
          <SubmitButton variant="ghost" pendingText="...">
            Nova senha
          </SubmitButton>
        </form>
        {totpEnabled ? (
          <form
            action={twoFactorAction}
            onSubmit={(e) => {
              if (!window.confirm(`Desligar a verificação em duas etapas de ${name}? Use quando a pessoa perdeu o celular.`)) e.preventDefault();
            }}
          >
            <input type="hidden" name="id" value={id} />
            <SubmitButton variant="ghost" pendingText="...">
              Resetar 2 etapas
            </SubmitButton>
          </form>
        ) : null}
        <form action={toggleAction}>
          <input type="hidden" name="id" value={id} />
          <input type="hidden" name="active" value={String(!active)} />
          <SubmitButton variant={active ? "ghost" : "secondary"} pendingText="...">
            {active ? "Desativar" : "Reativar"}
          </SubmitButton>
        </form>
      </div>
      {reset.ok && reset.secret ? <TempPassword secret={reset.secret} /> : reset.message ? <FormMessage state={reset} /> : null}
      {toggle.message && !toggle.ok ? <FormMessage state={toggle} /> : null}
      {twoFactor.message ? <FormMessage state={twoFactor} /> : null}
      <Dialog open={editOpen} onClose={() => setEditOpen(false)} title={`Editar ${name}`}>
        <EditUserForm key={editKey} id={id} name={name} role={role} onSaved={() => setEditOpen(false)} />
      </Dialog>
    </div>
  );
}

function EditUserForm({ id, name, role, onSaved }: { id: string; name: string; role: string; onSaved: () => void }) {
  const [state, action] = useActionState(updateClinicUserAction, {});
  useRefreshOnOk(state);
  const saved = useEffectEvent(onSaved);
  useEffect(() => {
    if (state.ok) saved();
  }, [state]);
  return (
    <form action={action} className="space-y-4">
      <FormMessage state={state} />
      <input type="hidden" name="id" value={id} />
      <Field label="Nome" name="name" id={`eu-name-${id}`} defaultValue={state.values?.name ?? name} error={state.errors?.name} />
      <SelectField label="Perfil" name="role" id={`eu-role-${id}`} defaultValue={state.values?.role ?? role}>
        {CLINIC_ROLES.map((r) => (
          <option key={r} value={r}>
            {CLINIC_ROLE_LABEL[r]}
          </option>
        ))}
      </SelectField>
      <p className="text-xs text-ink-soft">O e-mail de login não muda: para trocar, crie um novo acesso e desative este.</p>
      <SubmitButton pendingText="Salvando...">Salvar</SubmitButton>
    </form>
  );
}

/* ----------------------------------- Canais ----------------------------------- */

export interface ChannelValues {
  channel: Channel;
  mode: ChannelMode;
  active: boolean;
  displayName: string;
  externalAccountId: string;
  serverReady: boolean;
}

const accountLabel: Record<Channel, { label: string; placeholder: string }> = {
  whatsapp: { label: "Phone number ID (Meta)", placeholder: "Ex.: 1234567890" },
  instagram: { label: "ID da conta profissional do Instagram", placeholder: "Ex.: 17841400000000000" },
  facebook: { label: "ID da página do Facebook", placeholder: "Ex.: 104000000000000" },
  telegram: { label: "Usuário do bot", placeholder: "Ex.: ClinicaExemploBot" },
};

export function ChannelForm({ initial }: { initial: ChannelValues }) {
  const [state, action] = useActionState(saveChannelAction, {});
  useRefreshOnOk(state);
  const c = initial.channel;
  return (
    <form action={action} className="space-y-3">
      <input type="hidden" name="channel" value={c} />
      <FormMessage state={state} />
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Nome exibido" name="displayName" id={`ch-dn-${c}`} defaultValue={initial.displayName} placeholder={c === "whatsapp" ? "(51) 3333-0000" : CHANNEL_LABEL[c]} />
        <Field
          label={accountLabel[c].label}
          name="externalAccountId"
          id={`ch-acc-${c}`}
          defaultValue={initial.externalAccountId}
          placeholder={accountLabel[c].placeholder}
          error={state.errors?.externalAccountId}
          hint="É assim que o webhook descobre que a mensagem é desta clínica."
        />
        <SelectField label="Modo" name="mode" id={`ch-mode-${c}`} defaultValue={initial.mode}>
          <option value="simulacao">Simulação (testes e treinamento)</option>
          <option value="real" disabled={!initial.serverReady}>
            Real{initial.serverReady ? "" : " (credencial ausente no servidor)"}
          </option>
        </SelectField>
        <CheckboxField name="active" defaultChecked={initial.active} label="Canal ativo" hint="Desativado: não envia nem recebe por este canal." className="sm:pt-5" />
      </div>
      <SubmitButton variant="secondary" pendingText="Salvando...">
        Salvar {CHANNEL_LABEL[c]}
      </SubmitButton>
    </form>
  );
}

/* ------------------------------- Profissionais -------------------------------- */

export interface ProfessionalValues {
  id?: string;
  name: string;
  specialty: string;
  color: string;
  slotMinutes: number;
  workStart: string;
  workEnd: string;
  breakStart: string;
  breakEnd: string;
  workDays: number[];
  userId: string;
  active: boolean;
}

const NEW_PROFESSIONAL: ProfessionalValues = {
  name: "",
  specialty: "",
  color: "crm",
  slotMinutes: 30,
  workStart: "08:00",
  workEnd: "18:00",
  breakStart: "12:00",
  breakEnd: "13:00",
  workDays: [1, 2, 3, 4, 5],
  userId: "",
  active: true,
};

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const COLORS: { id: string; label: string; dot: string }[] = [
  { id: "crm", label: "Roxo", dot: "bg-crm" },
  { id: "erp", label: "Amarelo", dot: "bg-erp" },
  { id: "pep", label: "Verde", dot: "bg-pep" },
  { id: "bi", label: "Azul", dot: "bg-bi" },
];

/**
 * Criar/editar profissional: expediente, intervalo, dias de atendimento e
 * duração da consulta. É isso que a agenda usa para mostrar horários livres.
 */
export function ProfessionalButton({ initial, users }: { initial?: ProfessionalValues; users: { id: string; name: string }[] }) {
  const [open, setOpen] = useState(false);
  const [formKey, setFormKey] = useState(0);
  return (
    <>
      <button
        type="button"
        onClick={() => {
          setFormKey((k) => k + 1);
          setOpen(true);
        }}
        className={buttonStyles(initial ? "ghost" : "primary")}
        aria-label={initial ? `Editar ${initial.name}` : undefined}
      >
        {initial ? <Pencil className="size-4" aria-hidden /> : <Plus className="size-4" aria-hidden />}
        {initial ? "Editar" : "Novo profissional"}
      </button>
      <Dialog open={open} onClose={() => setOpen(false)} title={initial ? `Editar ${initial.name}` : "Novo profissional"} description="O expediente define os horários livres da agenda." wide>
        <ProfessionalForm key={formKey} initial={initial ?? NEW_PROFESSIONAL} users={users} onSaved={() => setOpen(false)} />
      </Dialog>
    </>
  );
}

function ProfessionalForm({ initial, users, onSaved }: { initial: ProfessionalValues; users: { id: string; name: string }[]; onSaved: () => void }) {
  const [state, action] = useActionState(saveProfessionalAction, {});
  useRefreshOnOk(state);
  // Mensagem de sucesso com aviso (consultas fora do novo horário): mantém aberto para a pessoa ler
  const done = state.ok && !state.message?.includes("Atenção");
  const notifySaved = useEffectEvent(onSaved);
  useEffect(() => {
    if (done) notifySaved();
  }, [done]);

  const p = initial.id ?? "new";
  const val = (k: keyof ProfessionalValues) => state.values?.[k] ?? String(initial[k] ?? "");
  // Dias marcados: depois de um erro, o servidor devolve só o último valor de cada campo,
  // então os dias ficam no estado do navegador
  const [days, setDays] = useState<number[]>(initial.workDays);

  return (
    <form action={action} className="space-y-4">
      <FormMessage state={state} />
      {initial.id ? <input type="hidden" name="id" value={initial.id} /> : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nome" name="name" id={`pro-name-${p}`} placeholder="Dra. Ana Souza" defaultValue={val("name")} error={state.errors?.name} />
        <Field label="Especialidade" name="specialty" id={`pro-spec-${p}`} placeholder="Dermatologia" defaultValue={val("specialty")} />
      </div>

      <fieldset>
        <legend className="text-sm font-semibold">Dias de atendimento</legend>
        <div className="mt-1 flex flex-wrap gap-1.5">
          {WEEKDAYS.map((label, d) => (
            <label key={d} className="cursor-pointer">
              <input
                type="checkbox"
                name="workDays"
                value={d}
                checked={days.includes(d)}
                onChange={() => setDays((cur) => (cur.includes(d) ? cur.filter((x) => x !== d) : [...cur, d].sort()))}
                className="peer sr-only"
              />
              <span className="inline-flex min-h-10 min-w-12 items-center justify-center rounded-xl bg-fog px-3 text-sm font-semibold ring-1 ring-line peer-checked:bg-ink peer-checked:text-white peer-focus-visible:ring-2 peer-focus-visible:ring-crm">
                {label}
              </span>
            </label>
          ))}
        </div>
        {state.errors?.workDays ? <p className="mt-1 text-sm font-semibold text-alert">{state.errors.workDays}</p> : null}
      </fieldset>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        <Field label="Início" name="workStart" id={`pro-ws-${p}`} type="time" defaultValue={val("workStart")} error={state.errors?.workStart} />
        <Field label="Fim" name="workEnd" id={`pro-we-${p}`} type="time" defaultValue={val("workEnd")} error={state.errors?.workEnd} />
        <SelectField label="Duração da consulta" name="slotMinutes" id={`pro-slot-${p}`} defaultValue={val("slotMinutes")} error={state.errors?.slotMinutes} className="col-span-2 sm:col-span-1">
          {[10, 15, 20, 30, 40, 45, 50, 60, 90, 120].map((m) => (
            <option key={m} value={m}>
              {m < 60 ? `${m} min` : `${m / 60} h${m % 60 ? ` ${m % 60}` : ""}`}
            </option>
          ))}
        </SelectField>
        <Field label="Intervalo: início" name="breakStart" id={`pro-bs-${p}`} type="time" defaultValue={val("breakStart")} error={state.errors?.breakStart} />
        <Field label="Intervalo: fim" name="breakEnd" id={`pro-be-${p}`} type="time" defaultValue={val("breakEnd")} error={state.errors?.breakEnd} hint="Vazio = sem intervalo." />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <fieldset>
          <legend className="text-sm font-semibold">Cor na agenda</legend>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {COLORS.map((c) => (
              <label key={c.id} className="cursor-pointer">
                <input type="radio" name="color" value={c.id} defaultChecked={val("color") === c.id} className="peer sr-only" />
                <span className="inline-flex min-h-10 items-center gap-2 rounded-xl bg-fog px-3 text-sm font-semibold ring-1 ring-line peer-checked:ring-2 peer-checked:ring-ink peer-focus-visible:ring-crm">
                  <span className={`size-3 rounded-full ${c.dot}`} aria-hidden /> {c.label}
                </span>
              </label>
            ))}
          </div>
        </fieldset>
        <SelectField label="Acesso ao sistema" name="userId" id={`pro-user-${p}`} defaultValue={val("userId")} hint="Liga o profissional ao login dele.">
          <option value="">Sem acesso ligado</option>
          {users.map((u) => (
            <option key={u.id} value={u.id}>
              {u.name}
            </option>
          ))}
        </SelectField>
      </div>

      <CheckboxField name="active" defaultChecked={state.values ? state.values.active === "on" : initial.active} label="Atendendo" hint="Desmarque para tirar da agenda (exige não ter consultas futuras)." />
      <SubmitButton pendingText="Salvando...">Salvar profissional</SubmitButton>
    </form>
  );
}

/* ------------------------ Confirmação automática ----------------------------- */

export function CrmSettingsForm({ initial }: { initial: { autoConfirm: boolean; confirmHour: number; confirmDaysBefore: number } }) {
  const [state, action] = useActionState(saveCrmSettingsAction, {});
  useRefreshOnOk(state);
  return (
    <form action={action} className="space-y-4">
      <FormMessage state={state} />
      <CheckboxField
        name="autoConfirm"
        defaultChecked={initial.autoConfirm}
        label="Pedir confirmação automaticamente"
        hint="O paciente responde 1 para confirmar ou 2 para remarcar. Quem pediu SAIR não recebe."
      />
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectField label="Consultas de" name="confirmDaysBefore" id="cfg-days" defaultValue={String(initial.confirmDaysBefore)}>
          <option value="1">Amanhã</option>
          <option value="2">Em 2 dias</option>
          <option value="3">Em 3 dias</option>
        </SelectField>
        <SelectField label="Enviar a partir de" name="confirmHour" id="cfg-hour" defaultValue={String(initial.confirmHour)}>
          {Array.from({ length: 14 }, (_, i) => i + 7).map((h) => (
            <option key={h} value={h}>
              {String(h).padStart(2, "0")}:00
            </option>
          ))}
        </SelectField>
      </div>
      <SubmitButton variant="secondary" pendingText="Salvando...">
        Salvar preferências
      </SubmitButton>
    </form>
  );
}

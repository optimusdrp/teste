import { asc, schema, withTenant } from "@ecosaude/db";
import type { Metadata } from "next";
import { Badge, EmptyState, PageHeader } from "@/components/ui/server";
import { requireCrm } from "@/lib/auth/dal";
import { DeleteQuickReply, QuickReplyButton } from "../forms";

export const metadata: Metadata = { title: "Respostas rápidas" };
export const dynamic = "force-dynamic";

/** Respostas rápidas: textos prontos acionados com "/" na conversa. */
export default async function QuickRepliesPage() {
  const ctx = await requireCrm("config.respostas");
  const replies = await withTenant(ctx.user.clinicId, (tx) => tx.select().from(schema.quickReplies).orderBy(asc(schema.quickReplies.shortcut)));

  return (
    <>
      <PageHeader
        title="Respostas rápidas"
        description="Na conversa, digite / para escolher. As marcadas como modelo aprovado podem ser enviadas mesmo após 24h sem resposta do paciente."
        actions={<QuickReplyButton />}
      />
      {replies.length === 0 ? (
        <EmptyState title="Nenhuma resposta rápida">Crie as respostas que a recepção mais repete: endereço, valores, preparo de exame...</EmptyState>
      ) : (
        <ul className="grid grid-cols-[minmax(0,1fr)] gap-3 md:grid-cols-2">
          {replies.map((r) => (
            <li key={r.id} className="flex flex-col rounded-2xl bg-paper p-4 ring-1 ring-line">
              <div className="flex flex-wrap items-center gap-2">
                <code className="rounded-lg bg-crm-tint px-2 py-0.5 font-semibold text-crm">/{r.shortcut}</code>
                <span className="font-semibold">{r.title}</span>
                {r.approvedTemplate ? <Badge tone="success">modelo aprovado</Badge> : null}
              </div>
              <p className="mt-2 flex-1 text-sm whitespace-pre-line text-ink-soft">{r.body}</p>
              <div className="mt-2 flex gap-1">
                <QuickReplyButton initial={{ id: r.id, shortcut: r.shortcut, title: r.title, body: r.body, approvedTemplate: r.approvedTemplate }} />
                <DeleteQuickReply id={r.id} shortcut={r.shortcut} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

import { CLINIC_ROLE_LABEL } from "@ecosaude/core/crm";
import { db, desc, eq, schema } from "@ecosaude/db";
import type { Metadata } from "next";
import { PageHeader, Panel } from "@/components/ui/server";
import { requireUser } from "@/lib/auth/dal";
import { ChangePasswordForm } from "../../../(auth)/forms";
import { TwoFactorPanel } from "./TwoFactorPanel";

export const metadata: Metadata = { title: "Minha conta" };
export const dynamic = "force-dynamic";

const fmt = (d: Date) => d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short", timeZone: "America/Sao_Paulo" });

/** Minha conta: dados, 2FA opcional, troca de senha e aparelhos conectados. */
export default async function AccountPage() {
  const user = await requireUser();
  // Sessões ficam fora do papel da clínica (RLS): consulta direta, filtrada pelo próprio usuário
  const sessions = await db.query.clinicSessions.findMany({
    where: eq(schema.clinicSessions.userId, user.id),
    orderBy: desc(schema.clinicSessions.createdAt),
    columns: { id: true, createdAt: true, expiresAt: true, ip: true, userAgent: true },
  });

  return (
    <>
      <PageHeader title="Minha conta" description={`${user.name}, ${CLINIC_ROLE_LABEL[user.role]} na ${user.clinicName}. Login: ${user.email}`} />
      <div className="grid grid-cols-[minmax(0,1fr)] items-start gap-5 xl:grid-cols-2">
        <div className="space-y-5">
          <Panel title="Verificação em duas etapas" description="Opcional. Protege a conta mesmo que alguém descubra a sua senha.">
            <TwoFactorPanel enabled={user.totpEnabled} />
          </Panel>
          <Panel title="Trocar senha" description="Os outros aparelhos conectados serão desconectados.">
            <ChangePasswordForm from="conta" />
          </Panel>
        </div>
        <Panel title="Aparelhos conectados">
          <ul className="divide-y divide-line text-sm">
            {sessions.map((s) => (
              <li key={s.id} className="py-2.5">
                <p className="font-semibold">
                  {s.id === user.sessionId ? "Este aparelho" : "Outro aparelho"}
                  {s.ip ? `, IP ${s.ip}` : ""}
                </p>
                <p className="break-words text-ink-soft">{s.userAgent ?? "Navegador desconhecido"}</p>
                <p className="text-xs text-ink-soft">
                  Desde {fmt(s.createdAt)}, expira {fmt(s.expiresAt)}
                </p>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </>
  );
}

import { clinicCan } from "@ecosaude/core/crm";
import { requireUser } from "@/lib/auth/dal";
import { SettingsTabs } from "./SettingsTabs";

/**
 * AJUSTES: abas conforme o perfil.
 * Todos veem "Minha conta"; o gestor vê equipe e canais; recepção vê respostas rápidas.
 */
export default async function SettingsLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const tabs = [{ href: "/configuracoes/conta", label: "Minha conta" }];
  if (clinicCan(user.role, "config.clinica")) tabs.push({ href: "/configuracoes/clinica", label: "Clínica" });
  if (clinicCan(user.role, "config.respostas")) tabs.push({ href: "/configuracoes/respostas", label: "Respostas rápidas" });
  if (clinicCan(user.role, "config.equipe")) tabs.push({ href: "/configuracoes/equipe", label: "Equipe" });
  if (clinicCan(user.role, "config.canais")) tabs.push({ href: "/configuracoes/canais", label: "Canais" });
  return (
    <>
      <SettingsTabs tabs={tabs} />
      {children}
    </>
  );
}

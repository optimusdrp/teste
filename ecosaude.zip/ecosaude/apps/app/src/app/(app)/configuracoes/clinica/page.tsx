import { AUTO_CONFIRM_LAST_HOUR } from "@ecosaude/core/crm";
import { asc, eq, inSequence, schema, withTenant } from "@ecosaude/db";
import type { Metadata } from "next";
import { Badge, colorOf, EmptyState, PageHeader, Panel } from "@/components/ui/server";
import { cn } from "@/components/ui/styles";
import { requireCrm } from "@/lib/auth/dal";
import { CrmSettingsForm, ProfessionalButton } from "../forms";

export const metadata: Metadata = { title: "Clínica" };
export const dynamic = "force-dynamic";

const WEEKDAYS = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];

/** Resume os dias: "seg a sex", "seg, qua, sex". */
function daysLabel(days: number[]): string {
  const sorted = [...days].sort();
  const consecutive = sorted.every((d, i) => i === 0 || d === sorted[i - 1]! + 1);
  if (sorted.length >= 3 && consecutive) return `${WEEKDAYS[sorted[0]!]} a ${WEEKDAYS[sorted[sorted.length - 1]!]}`;
  return sorted.map((d) => WEEKDAYS[d]).join(", ");
}

/**
 * AJUSTES > CLÍNICA (gestão)
 * Profissionais e seus horários (base da agenda) e a confirmação automática.
 */
export default async function ClinicSettingsPage() {
  const ctx = await requireCrm("config.clinica");
  const [pros, users, settings] = await withTenant(ctx.user.clinicId, (tx) =>
    inSequence([
      () => tx.select().from(schema.professionals).orderBy(asc(schema.professionals.name)),
      () => tx.select({ id: schema.clinicUsers.id, name: schema.clinicUsers.name }).from(schema.clinicUsers).where(eq(schema.clinicUsers.active, true)).orderBy(asc(schema.clinicUsers.name)),
      () => tx.select().from(schema.crmSettings).limit(1),
    ]),
  );
  // Sem linha salva ainda = valores padrão (iguais aos do banco)
  const cfg = settings[0] ?? { autoConfirm: true, confirmHour: 10, confirmDaysBefore: 1, lastAutoConfirmOn: null };
  const userName = new Map(users.map((u) => [u.id, u.name]));

  return (
    <>
      <PageHeader title="Clínica" description="Quem atende, em quais horários, e o que o CRM faz sozinho." />
      <div className="grid grid-cols-[minmax(0,1fr)] items-start gap-5 xl:grid-cols-[minmax(0,1fr)_24rem]">
        <Panel
          title="Profissionais"
          description="O expediente e a duração da consulta definem os horários livres da agenda e da lista de espera."
          actions={<ProfessionalButton users={users} />}
        >
          {pros.length === 0 ? (
            <EmptyState title="Nenhum profissional">Cadastre quem atende para começar a usar a agenda.</EmptyState>
          ) : (
            <ul className="divide-y divide-line">
              {pros.map((p) => (
                <li key={p.id} className={cn("flex flex-wrap items-center gap-3 py-3", !p.active && "opacity-60")}>
                  <span className={cn("size-3 shrink-0 rounded-full", colorOf(p.color).dot)} aria-hidden />
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold">
                      {p.name}
                      {p.specialty ? <span className="font-normal text-ink-soft">{`, ${p.specialty}`}</span> : null}
                    </p>
                    <p className="text-sm text-ink-soft">
                      {daysLabel(p.workDays)}, {p.workStart} às {p.workEnd}
                      {p.breakStart && p.breakEnd ? ` (intervalo ${p.breakStart} às ${p.breakEnd})` : ""}, consultas de {p.slotMinutes} min
                    </p>
                    <div className="mt-1 flex flex-wrap gap-1">
                      {!p.active ? <Badge>fora da agenda</Badge> : null}
                      {p.userId ? <Badge tone="crm">acesso: {userName.get(p.userId) ?? "usuário desativado"}</Badge> : null}
                    </div>
                  </div>
                  <ProfessionalButton
                    users={users}
                    initial={{
                      id: p.id,
                      name: p.name,
                      specialty: p.specialty ?? "",
                      color: p.color,
                      slotMinutes: p.slotMinutes,
                      workStart: p.workStart,
                      workEnd: p.workEnd,
                      breakStart: p.breakStart ?? "",
                      breakEnd: p.breakEnd ?? "",
                      workDays: p.workDays,
                      userId: p.userId ?? "",
                      active: p.active,
                    }}
                  />
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel title="Confirmação automática" description="Menos faltas sem ninguém precisar lembrar de enviar.">
          <CrmSettingsForm initial={{ autoConfirm: cfg.autoConfirm, confirmHour: cfg.confirmHour, confirmDaysBefore: cfg.confirmDaysBefore }} />
          <p className="mt-4 rounded-xl bg-fog p-3 text-sm text-ink-soft">
            {cfg.autoConfirm
              ? `Todos os dias, das ${String(cfg.confirmHour).padStart(2, "0")}h às ${AUTO_CONFIRM_LAST_HOUR}h, o CRM pede confirmação das consultas de ${cfg.confirmDaysBefore === 1 ? "amanhã" : `daqui a ${cfg.confirmDaysBefore} dias`} que ainda não receberam o pedido (inclusive as marcadas ao longo do dia). Ninguém recebe duas vezes.`
              : "Desligada: use o botão “Pedir confirmação” na Agenda ou no painel Hoje."}
            {cfg.lastAutoConfirmOn ? ` Último envio automático: ${cfg.lastAutoConfirmOn.split("-").reverse().join("/")}.` : ""}
          </p>
        </Panel>
      </div>
    </>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/components/ui/styles";

/** Abas dos Ajustes (rolagem horizontal no celular). */
export function SettingsTabs({ tabs }: { tabs: { href: string; label: string }[] }) {
  const path = usePathname();
  return (
    <nav aria-label="Ajustes" className="-mx-3 mb-5 overflow-x-auto px-3 sm:mx-0 sm:px-0">
      <ul className="flex w-max gap-1 rounded-2xl bg-paper p-1 ring-1 ring-line">
        {tabs.map((t) => {
          const active = path.startsWith(t.href);
          return (
            <li key={t.href}>
              <Link
                href={t.href}
                aria-current={active ? "page" : undefined}
                className={cn("inline-flex min-h-10 items-center rounded-xl px-4 text-sm font-semibold whitespace-nowrap", active ? "bg-ink text-white" : "text-ink-soft hover:text-ink")}
              >
                {t.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

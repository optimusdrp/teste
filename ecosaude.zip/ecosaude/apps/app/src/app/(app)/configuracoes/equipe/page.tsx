import { CLINIC_ROLE_LABEL } from "@ecosaude/core/crm";
import { asc, schema, withTenant } from "@ecosaude/db";
import type { Metadata } from "next";
import { Avatar, Badge, PageHeader } from "@/components/ui/server";
import { requireCrm } from "@/lib/auth/dal";
import { now } from "@/lib/clock";
import { ago } from "@/modules/crm/format";
import { NewUserButton, UserActions } from "../forms";

export const metadata: Metadata = { title: "Equipe" };
export const dynamic = "force-dynamic";

/** Equipe da clínica: quem acessa, com qual perfil, e controle de acesso. */
export default async function TeamPage() {
  const ctx = await requireCrm("config.equipe");
  const current = now();
  const users = await withTenant(ctx.user.clinicId, (tx) =>
    tx
      .select({
        id: schema.clinicUsers.id,
        name: schema.clinicUsers.name,
        email: schema.clinicUsers.email,
        role: schema.clinicUsers.role,
        active: schema.clinicUsers.active,
        mustChangePassword: schema.clinicUsers.mustChangePassword,
        totpEnabled: schema.clinicUsers.totpEnabled,
        lastLoginAt: schema.clinicUsers.lastLoginAt,
        lockedUntil: schema.clinicUsers.lockedUntil,
      })
      .from(schema.clinicUsers)
      .orderBy(asc(schema.clinicUsers.name)),
  );

  return (
    <>
      <PageHeader title="Equipe" description="Cada pessoa tem o próprio acesso: o histórico mostra quem fez o quê." actions={<NewUserButton />} />
      <ul className="grid grid-cols-[minmax(0,1fr)] gap-3 lg:grid-cols-2">
        {users.map((u) => (
          <li key={u.id} className="rounded-2xl bg-paper p-4 ring-1 ring-line">
            <div className="flex items-start gap-3">
              <Avatar name={u.name} />
              <div className="min-w-0 flex-1">
                <p className="font-semibold">
                  {u.name} {u.id === ctx.user.id ? <span className="text-sm font-normal text-ink-soft">(você)</span> : null}
                </p>
                <p className="truncate text-sm text-ink-soft">{u.email}</p>
                <div className="mt-1 flex flex-wrap gap-1">
                  <Badge tone="crm">{CLINIC_ROLE_LABEL[u.role]}</Badge>
                  {!u.active ? <Badge tone="alert">desativado</Badge> : null}
                  {u.mustChangePassword ? <Badge tone="warning">senha temporária</Badge> : null}
                  {u.totpEnabled ? <Badge tone="success">2 etapas</Badge> : null}
                  {u.lockedUntil && u.lockedUntil > current ? <Badge tone="alert">bloqueado por tentativas</Badge> : null}
                </div>
                <p className="mt-1 text-xs text-ink-soft">{u.lastLoginAt ? `Último acesso ${ago(u.lastLoginAt, current.getTime())}` : "Nunca acessou"}</p>
              </div>
            </div>
            {u.id !== ctx.user.id ? (
              <div className="mt-3 border-t border-line pt-2">
                <UserActions id={u.id} name={u.name} active={u.active} role={u.role} totpEnabled={u.totpEnabled} />
              </div>
            ) : null}
          </li>
        ))}
      </ul>
    </>
  );
}

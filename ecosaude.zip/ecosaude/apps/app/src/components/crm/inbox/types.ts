/**
 * Tipos da MESA DE MENSAGENS (dados que o servidor entrega já prontos para a tela).
 * Datas viram números (ms) para atravessar do servidor para o navegador.
 */
import type { Channel, JourneyStage } from "@ecosaude/core/crm";

export interface InboxItem {
  id: string;
  contactId: string;
  contactName: string;
  channel: Channel;
  status: string;
  preview: string | null;
  lastMessageMs: number | null;
  /** Desde quando espera resposta (null = ninguém esperando) */
  waitingSinceMs: number | null;
  snoozedUntilMs: number | null;
  unread: number;
  urgent: boolean;
  intentLabel: string | null;
  assigneeId: string | null;
  assigneeName: string | null;
}

export interface InboxCounts {
  esperando: number;
  abertas: number;
  minhas: number;
  sem_dono: number;
  adiadas: number;
  /** Esperando há mais que a meta de 1ª resposta */
  atrasadas: number;
  maisAntigaMs: number | null;
  naoLidas: number;
}

export interface ThreadMessage {
  id: string;
  direction: "in" | "out" | "note" | "system";
  body: string;
  status: string;
  createdMs: number;
  /** "seg, 12/10" e "14:30", calculados no fuso da clínica */
  dayLabel: string;
  time: string;
  authorName: string | null;
  auto: boolean;
  handledBy: string | null;
  error: string | null;
}

export interface ThreadData {
  id: string;
  channel: Channel;
  status: string;
  urgent: boolean;
  urgentGuidance: string | null;
  unread: number;
  assigneeId: string | null;
  intent: string | null;
  intentLabel: string | null;
  contact: {
    id: string;
    name: string;
    phone: string | null;
    email: string | null;
    stage: JourneyStage;
    tags: string[];
    source: string | null;
    optedOut: boolean;
    consentMarketing: boolean;
    lastVisit: string | null;
    since: string;
  };
  messages: ThreadMessage[];
  otherChannels: { id: string; channel: Channel }[];
  next: { label: string; professional: string; status: string } | null;
  slots: string[];
  suggestionPro: string | null;
  suggestions: string[];
  window: { open: boolean; closesAtMs: number | null; closesLabel: string | null; unlimited: boolean };
  stats: { compareceu: number; faltou: number; cancelado: number };
  events: { id: string; text: string; when: string }[];
}

/* ------------------------------ Personalização ------------------------------ */

export interface InboxPrefs {
  density: "compacta" | "confortavel";
  /** Mostrar o trecho da última mensagem na lista */
  showPreview: boolean;
  /** Painel do assistente/paciente à direita (telas largas) */
  showPanel: boolean;
  panelTab: "assistente" | "paciente" | "historico";
  /** Depois de resolver, abrir a próxima da lista */
  autoAdvance: boolean;
  /** Enter envia (senão, Ctrl+Enter) */
  enterToSend: boolean;
}

export const DEFAULT_INBOX_PREFS: InboxPrefs = {
  density: "confortavel",
  showPreview: true,
  showPanel: true,
  panelTab: "assistente",
  autoAdvance: true,
  enterToSend: true,
};

export const PREFS_KEY = "eco:conversas:prefs:v1";

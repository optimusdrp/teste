/**
 * Eventos do navegador para componentes conversarem sem estado global.
 * Ex.: um botão em qualquer tela abre o trilho do paciente ou o simulador.
 */
export interface AppEvents {
  "eco:open-patient": string;
  "eco:open-commands": undefined;
  "eco:open-simulator": undefined;
  "eco:open-schedule": { contactId?: string; contactName?: string; conversationId?: string; professionalId?: string; service?: string; date?: string; time?: string };
  "eco:fill-composer": { body: string; templateId?: string };
}

export function emit<K extends keyof AppEvents>(name: K, detail?: AppEvents[K]) {
  window.dispatchEvent(new CustomEvent(name, { detail }));
}

export function listen<K extends keyof AppEvents>(name: K, handler: (detail: AppEvents[K]) => void): () => void {
  const wrapped = (event: Event) => handler((event as CustomEvent<AppEvents[K]>).detail);
  window.addEventListener(name, wrapped);
  return () => window.removeEventListener(name, wrapped);
}

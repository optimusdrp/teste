import "server-only";
import { hashToken } from "@ecosaude/auth/crypto";
import { clinicCan, type ClinicPermission, type ClinicRole, type CrmFeature } from "@ecosaude/core/crm";
import { and, db, eq, getClinicEntitlements, gte, schema, type ClinicEntitlements } from "@ecosaude/db";
import { redirect } from "next/navigation";
import { cache } from "react";
import { readSessionToken } from "./session";

/**
 * Camada de acesso (DAL): toda página e toda action passa por aqui.
 * - quem é o usuário e de qual clínica (pela sessão)
 * - se concluiu as etapas de segurança (senha definitiva, 2FA quando ativa)
 * - se o perfil tem a permissão
 * - se a clínica contratou o módulo e a funcionalidade
 */

export interface CurrentUser {
  id: string;
  name: string;
  email: string;
  role: ClinicRole;
  clinicId: string;
  clinicName: string;
  totpEnabled: boolean;
  mustChangePassword: boolean;
  twoFactorPassed: boolean;
  sessionId: string;
}

export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const token = await readSessionToken();
  if (!token) return null;

  const [row] = await db
    .select({ session: schema.clinicSessions, user: schema.clinicUsers, clinic: schema.clinics })
    .from(schema.clinicSessions)
    .innerJoin(schema.clinicUsers, eq(schema.clinicSessions.userId, schema.clinicUsers.id))
    .innerJoin(schema.clinics, eq(schema.clinicUsers.clinicId, schema.clinics.id))
    .where(and(eq(schema.clinicSessions.id, hashToken(token)), gte(schema.clinicSessions.expiresAt, new Date())))
    .limit(1);

  if (!row || !row.user.active) return null;
  return {
    id: row.user.id,
    name: row.user.name,
    email: row.user.email,
    role: row.user.role,
    clinicId: row.clinic.id,
    clinicName: row.clinic.tradeName,
    totpEnabled: row.user.totpEnabled,
    mustChangePassword: row.user.mustChangePassword,
    twoFactorPassed: row.session.twoFactorPassed,
    sessionId: row.session.id,
  };
});

export type PendingStep = "two-factor" | "change-password" | null;

export function pendingStep(user: CurrentUser): PendingStep {
  if (user.totpEnabled && !user.twoFactorPassed) return "two-factor";
  if (user.mustChangePassword) return "change-password";
  return null;
}

const stepRoute: Record<Exclude<PendingStep, null>, string> = {
  "two-factor": "/login/verificacao",
  "change-password": "/primeiro-acesso",
};

export function routeForStep(step: Exclude<PendingStep, null>): string {
  return stepRoute[step];
}

export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const step = pendingStep(user);
  if (step) redirect(stepRoute[step]);
  return user;
}

/** Módulos e funcionalidades que a clínica pode usar agora (calculado uma vez por requisição). */
export const getEntitlements = cache((clinicId: string): Promise<ClinicEntitlements> => getClinicEntitlements(clinicId));

export interface CrmContext {
  user: CurrentUser;
  entitlements: ClinicEntitlements;
  has: (feature: CrmFeature) => boolean;
  can: (permission: ClinicPermission) => boolean;
}

/**
 * Para páginas do CRM: exige login, módulo CRM contratado e (opcional) uma permissão.
 * Sem o módulo, mostra a página explicando que ele não está ativo.
 */
export async function requireCrm(permission?: ClinicPermission): Promise<CrmContext> {
  const user = await requireUser();
  if (permission && !clinicCan(user.role, permission)) redirect("/sem-permissao");
  const entitlements = await getEntitlements(user.clinicId);
  if (!entitlements.modules.includes("crm")) redirect("/modulos/crm");
  return {
    user,
    entitlements,
    has: (f) => entitlements.features.includes(f),
    can: (p) => clinicCan(user.role, p),
  };
}

/**
 * Para server actions: devolve o contexto ou null (sem redirecionar),
 * conferindo login, módulo, permissão e, se pedido, a funcionalidade do plano.
 */
export async function authorizeCrm(permission: ClinicPermission, feature?: CrmFeature): Promise<CrmContext | null> {
  const user = await getCurrentUser();
  if (!user || pendingStep(user) || !clinicCan(user.role, permission)) return null;
  const entitlements = await getEntitlements(user.clinicId);
  if (!entitlements.modules.includes("crm")) return null;
  if (feature && !entitlements.features.includes(feature)) return null;
  return {
    user,
    entitlements,
    has: (f) => entitlements.features.includes(f),
    can: (p) => clinicCan(user.role, p),
  };
}

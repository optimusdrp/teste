/**
 * Testes das regras puras do CRM.
 * Rodar: pnpm --filter @ecosaude/core test
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { compareContacts, normalizeName, phoneKey } from "./duplicates";
import { professionalSchema } from "./validation";
import {
  detectIntent,
  detectUrgency,
  fillTemplate,
  findFreeSlots,
  isAffirmative,
  isOptOut,
  noShowRisk,
  parseNpsScore,
  utcToZoned,
  zonedToUtc,
} from "./index";

describe("fuso da clínica", () => {
  it("converte 14:30 de São Paulo para 17:30 UTC", () => {
    assert.equal(zonedToUtc("2026-10-09", "14:30").toISOString(), "2026-10-09T17:30:00.000Z");
  });
  it("volta para o horário local", () => {
    const p = utcToZoned(new Date("2026-10-09T17:30:00Z"));
    assert.deepEqual([p.date, p.time, p.weekday], ["2026-10-09", "14:30", 5]);
  });
});

describe("horários livres", () => {
  const schedule = { workDays: [1, 2, 3, 4, 5], start: "08:00", end: "12:00", slotMinutes: 60 };
  it("pula horários ocupados e o fim de semana", () => {
    // sexta 09/10 às 07:00 local; ocupado 08:00-09:00
    const from = zonedToUtc("2026-10-09", "07:00");
    const busy = [{ startsAt: zonedToUtc("2026-10-09", "08:00"), endsAt: zonedToUtc("2026-10-09", "09:00") }];
    const slots = findFreeSlots({ schedule, busy, from, limit: 4, minLeadMinutes: 0 });
    const labels = slots.map((s) => `${utcToZoned(s.startsAt).date} ${utcToZoned(s.startsAt).time}`);
    assert.deepEqual(labels, ["2026-10-09 09:00", "2026-10-09 10:00", "2026-10-09 11:00", "2026-10-12 08:00"]);
  });
  it("filtra período da tarde", () => {
    const sched = { ...schedule, end: "18:00" };
    const slots = findFreeSlots({ schedule: sched, busy: [], from: zonedToUtc("2026-10-09", "07:00"), period: "tarde", limit: 1 });
    assert.equal(utcToZoned(slots[0]!.startsAt).time, "12:00");
  });
});

describe("risco de falta", () => {
  it("histórico de faltas sem confirmação é alto", () => {
    const r = noShowRisk({ pastNoShows: 2, pastAttended: 1, confirmed: false, hoursUntil: 20, leadTimeDays: 10 });
    assert.equal(r.level, "alto");
    assert.ok(r.reasons.includes("Faltou 2 de 3 consultas"));
  });
  it("paciente assíduo que confirmou é baixo", () => {
    const r = noShowRisk({ pastNoShows: 0, pastAttended: 5, confirmed: true, hoursUntil: 20, leadTimeDays: 3 });
    assert.equal(r.level, "baixo");
  });
});

describe("mensagens", () => {
  it("detecta intenções em português informal", () => {
    assert.equal(detectIntent("Oi, queria marcar uma consulta"), "agendar");
    assert.equal(detectIntent("preciso remarcar minha consulta de amanhã"), "remarcar");
    assert.equal(detectIntent("não vou poder ir, quero cancelar"), "cancelar");
    assert.equal(detectIntent("Confirmo a consulta"), "confirmar");
    assert.equal(detectIntent("Quanto custa a consulta particular?"), "preco");
    // "minha agenda" não é pedido de agendamento
    assert.equal(detectIntent("Vou ver minha agenda e te falo"), null);
  });
  it("sinaliza urgência sem falso positivo comum", () => {
    assert.equal(detectUrgency("estou com dor no peito e falta de ar").urgent, true);
    assert.equal(detectUrgency("estou com dor no peito e falta de ar").kind, "clinica");
    assert.equal(detectUrgency("não quero mais viver").kind, "emocional");
    assert.equal(detectUrgency("queria marcar um retorno").urgent, false);
  });
  it("respostas curtas", () => {
    assert.ok(isAffirmative("Sim!"));
    assert.ok(isAffirmative("1"));
    assert.ok(!isAffirmative("sim, mas preciso remarcar"));
    assert.ok(isOptOut("SAIR"));
    assert.equal(parseNpsScore("nota 9"), 9);
    assert.equal(parseNpsScore("10!"), 10);
    assert.equal(parseNpsScore("11"), null);
  });
  it("preenche modelos sem deixar variável aparente", () => {
    assert.equal(fillTemplate("Olá {{primeiro_nome}}, {{data}} às {{hora}}", { primeiro_nome: "Ana", hora: "14:00" }), "Olá Ana, às 14:00");
  });
});

describe("cadastro de profissional", () => {
  const base = {
    name: "Dra. Teste",
    color: "crm",
    slotMinutes: "30",
    workStart: "08:00",
    workEnd: "18:00",
    breakStart: "12:00",
    breakEnd: "13:00",
    workDays: ["1", "2", "3"],
    active: true,
  };
  it("aceita expediente válido e converte números", () => {
    const r = professionalSchema.safeParse(base);
    assert.ok(r.success);
    assert.deepEqual(r.data.workDays, [1, 2, 3]);
    assert.equal(r.data.slotMinutes, 30);
  });
  it("aceita sem intervalo", () => {
    assert.ok(professionalSchema.safeParse({ ...base, breakStart: "", breakEnd: "" }).success);
  });
  it("recusa fim antes do início, intervalo pela metade ou fora do expediente, e nenhum dia", () => {
    assert.equal(professionalSchema.safeParse({ ...base, workEnd: "07:00" }).success, false);
    assert.equal(professionalSchema.safeParse({ ...base, breakEnd: "" }).success, false);
    assert.equal(professionalSchema.safeParse({ ...base, breakStart: "19:00", breakEnd: "20:00" }).success, false);
    assert.equal(professionalSchema.safeParse({ ...base, workDays: [] }).success, false);
  });
});

describe("duplicidade de cadastros", () => {
  it("normaliza nomes e telefones", () => {
    assert.equal(normalizeName("Dra. Ána Lúcia  dos Reis"), "ana lucia reis");
    assert.equal(phoneKey("5551999990000"), phoneKey("(51) 99999-0000"));
    assert.equal(phoneKey("51 9999-0000"), phoneKey("5551999990000"), "sem o 9º dígito também bate");
  });
  it("mesmo celular é suspeita forte, mesmo com nomes diferentes", () => {
    const m = compareContacts({ name: "Ana Reis", phone: "51999990000" }, { name: "Mãe da Ana", phone: "5551999990000" });
    assert.equal(m?.strength, "forte");
    assert.ok(m?.reasons.includes("mesmo celular"));
  });
  it("nome parecido é suspeita média; primeiro nome diferente não", () => {
    assert.equal(compareContacts({ name: "Ana Lucia Reis" }, { name: "Ana Lúcia dos Reis" })?.strength, "media");
    assert.equal(compareContacts({ name: "Luiza Mendes" }, { name: "Luisa Mendes" })?.strength, "media");
    assert.equal(compareContacts({ name: "Ana L. Reis" }, { name: "Ana Lúcia Reis" })?.strength, "media", "inicial abreviada");
    assert.equal(compareContacts({ name: "Ana Reis" }, { name: "Paula Reis" }), null);
    assert.equal(compareContacts({ name: "Carlos Souza" }, { name: "Carlos Andrade" }), null);
  });
  it("nome + nascimento iguais é suspeita forte", () => {
    const m = compareContacts({ name: "Jorge Batista", birthDate: "1980-02-01" }, { name: "Jorge B. Batista", birthDate: "1980-02-01" });
    assert.equal(m?.strength, "forte");
  });
});

/**
 * Validações dos formulários do CRM (usadas no navegador E no servidor).
 */
import { z } from "zod";
import { passwordSchema } from "../validation/index";
import {
  APPOINTMENT_STATUSES,
  CHANNELS,
  CLINIC_ROLES,
  JOURNEY_STAGES,
  WAITLIST_PERIODS,
} from "./constants";

const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .optional()
    .transform((v) => (v ? v : undefined));

/** Telefone: guarda só números, com DDI 55 quando vier só DDD + número. */
export const phoneSchema = z
  .string()
  .trim()
  .transform((v) => v.replace(/\D/g, ""))
  .refine((v) => v === "" || (v.length >= 10 && v.length <= 13), "Telefone inválido. Use DDD + número.")
  .transform((v) => (v === "" ? undefined : v.length <= 11 ? `55${v}` : v));

export const contactSchema = z.object({
  name: z.string().trim().min(2, "Informe o nome.").max(120),
  phone: phoneSchema,
  email: z.union([z.email("E-mail inválido."), z.literal("")]).transform((v) => v || undefined),
  birthDate: z
    .union([z.iso.date({ error: "Data inválida." }), z.literal("")])
    .transform((v) => v || undefined),
  preferredChannel: z.union([z.enum(CHANNELS), z.literal("")]).transform((v) => v || undefined),
  source: optionalText(60),
  tags: z
    .string()
    .optional()
    .transform((v) =>
      (v ?? "")
        .split(",")
        .map((t) => t.trim().toLowerCase())
        .filter(Boolean)
        .slice(0, 12),
    ),
  consentMarketing: z.boolean(),
  /** Versão lida pela tela (controle de edição simultânea). */
  version: z.coerce.number().int().min(1).optional(),
});

export const stageChangeSchema = z.object({
  contactId: z.uuid(),
  stage: z.enum(JOURNEY_STAGES),
  lostReason: optionalText(300),
});

export const noteSchema = z.object({
  contactId: z.uuid(),
  body: z.string().trim().min(1, "Escreva a anotação.").max(2000),
  /** ID gerado no navegador: reenviar a mesma nota (ex.: rede instável) não duplica. */
  clientId: z.uuid().optional(),
});

export const sendMessageSchema = z.object({
  conversationId: z.uuid(),
  body: z.string().trim().min(1, "Escreva a mensagem.").max(4000),
  internal: z.boolean(),
  clientId: z.uuid(),
  /** Mensagem a partir de modelo aprovado (permitida fora da janela de 24h). */
  templateId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
});

/** Duração opcional da consulta, em minutos (vazio = padrão do profissional) */
const durationField = z
  .union([z.coerce.number().int().min(5, "Mínimo de 5 minutos.").max(480, "Máximo de 8 horas."), z.literal("")])
  .optional()
  .transform((v) => (v === "" || v === undefined ? undefined : v));

export const appointmentSchema = z.object({
  contactId: z.uuid({ error: "Escolha o paciente." }),
  professionalId: z.uuid({ error: "Escolha o profissional." }),
  date: z.iso.date({ error: "Informe a data." }),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Informe o horário."),
  service: optionalText(80),
  notes: optionalText(500),
  /** De onde veio a marcação (conversa, recepção, lista de espera) */
  source: z.enum(["recepcao", "conversa", "lista_espera"]).default("recepcao"),
  /** Mensagem de proposta ao paciente pelo canal da conversa */
  notifyConversationId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
  /** Duração própria (vazio = a duração padrão do profissional) */
  durationMinutes: durationField,
});

export const appointmentStatusSchema = z.object({
  id: z.uuid(),
  status: z.enum(APPOINTMENT_STATUSES),
  reason: optionalText(300),
  version: z.coerce.number().int().min(1),
});

/** Remarcar: novo dia/horário (e, se quiser, outro profissional). */
export const rescheduleSchema = z.object({
  id: z.uuid(),
  version: z.coerce.number().int().min(1),
  professionalId: z.uuid({ error: "Escolha o profissional." }),
  date: z.iso.date({ error: "Informe a data." }),
  time: z.string().regex(/^\d{2}:\d{2}$/, "Escolha o horário."),
  /** Avisar o paciente pelo canal dele */
  notify: z.boolean(),
  durationMinutes: durationField,
});

/** Corrigir serviço, observações e duração de uma consulta já marcada. */
export const appointmentDetailsSchema = z.object({
  id: z.uuid(),
  version: z.coerce.number().int().min(1),
  service: optionalText(80),
  notes: optionalText(500),
  durationMinutes: durationField,
});

/* ------------------------------ Profissionais ------------------------------ */

const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "Use o formato 08:00.");
const toMinutes = (v: string) => Number(v.slice(0, 2)) * 60 + Number(v.slice(3, 5));

export const PROFESSIONAL_COLORS = ["crm", "erp", "pep", "bi"] as const;

export const professionalSchema = z
  .object({
    id: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
    name: z.string().trim().min(2, "Informe o nome.").max(120),
    specialty: optionalText(80),
    color: z.enum(PROFESSIONAL_COLORS),
    slotMinutes: z.coerce.number().int().min(5, "Mínimo de 5 minutos.").max(240, "Máximo de 4 horas."),
    workStart: hhmm,
    workEnd: hhmm,
    /** Intervalo é opcional: os dois vazios = sem intervalo */
    breakStart: z.union([hhmm, z.literal("")]).transform((v) => v || undefined),
    breakEnd: z.union([hhmm, z.literal("")]).transform((v) => v || undefined),
    workDays: z.array(z.coerce.number().int().min(0).max(6)).min(1, "Marque pelo menos um dia."),
    /** Usuário do sistema ligado a este profissional (vê a própria agenda) */
    userId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
    active: z.boolean(),
  })
  .superRefine((d, ctx) => {
    const start = toMinutes(d.workStart);
    const end = toMinutes(d.workEnd);
    if (end <= start) ctx.addIssue({ code: "custom", path: ["workEnd"], message: "O fim precisa ser depois do início." });
    else if (end - start < d.slotMinutes) ctx.addIssue({ code: "custom", path: ["slotMinutes"], message: "Não cabe nenhuma consulta no expediente." });
    if (!!d.breakStart !== !!d.breakEnd) {
      ctx.addIssue({ code: "custom", path: ["breakEnd"], message: "Informe início e fim do intervalo, ou deixe os dois vazios." });
    } else if (d.breakStart && d.breakEnd) {
      const bs = toMinutes(d.breakStart);
      const be = toMinutes(d.breakEnd);
      if (be <= bs) ctx.addIssue({ code: "custom", path: ["breakEnd"], message: "O fim do intervalo precisa ser depois do início." });
      else if (bs < start || be > end) ctx.addIssue({ code: "custom", path: ["breakStart"], message: "O intervalo precisa estar dentro do expediente." });
    }
  });

/* ------------------------- Preferências do CRM ----------------------------- */

export const crmSettingsSchema = z.object({
  autoConfirm: z.boolean(),
  confirmHour: z.coerce.number().int().min(0).max(23),
  confirmDaysBefore: z.coerce.number().int().min(1).max(3),
});

/** Abrir conversa com o paciente por um canal. */
export const startConversationSchema = z.object({
  contactId: z.uuid(),
  channel: z.enum(CHANNELS),
});

export const waitlistSchema = z.object({
  contactId: z.uuid({ error: "Escolha o paciente." }),
  professionalId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
  period: z.enum(WAITLIST_PERIODS),
  notes: optionalText(300),
});

export const quickReplySchema = z.object({
  id: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
  shortcut: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9-]{2,24}$/, "Use de 2 a 24 letras, números ou hífen (sem a barra)."),
  title: z.string().trim().min(2, "Informe o título.").max(60),
  body: z.string().trim().min(2, "Escreva a mensagem.").max(1000),
  approvedTemplate: z.boolean(),
});

export const returnProtocolSchema = z.object({
  id: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
  name: z.string().trim().min(2, "Informe o nome.").max(80),
  serviceMatch: optionalText(80),
  daysAfter: z.coerce.number().int().min(7, "Mínimo de 7 dias.").max(730, "Máximo de 2 anos."),
  message: z.string().trim().min(10, "Escreva a mensagem.").max(1000),
  active: z.boolean(),
});

export const taskSchema = z.object({
  /** Tarefa sem paciente também vale (ex.: "conferir estoque de luvas") */
  contactId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
  title: z.string().trim().min(2, "Descreva a tarefa.").max(160),
  dueDate: z.iso.date({ error: "Informe a data." }),
  /** Responsável (vazio = quem está criando) */
  assigneeId: z.union([z.uuid(), z.literal("")]).optional().transform((v) => v || undefined),
});

export const clinicUserSchema = z.object({
  name: z.string().trim().min(2, "Informe o nome.").max(120),
  email: z.email("E-mail inválido."),
  role: z.enum(CLINIC_ROLES),
});

/** Mensagem enviada "como paciente" pelo simulador de canais. */
export const simulatorMessageSchema = z.object({
  channel: z.enum(CHANNELS),
  /** Identificador no canal: telefone (WhatsApp), @usuário (Telegram/Instagram) ou nome (Messenger) */
  externalId: z.string().trim().min(2, "Informe quem envia.").max(80),
  name: z.string().trim().max(120).optional(),
  text: z.string().trim().min(1, "Escreva a mensagem.").max(2000),
});

export { passwordSchema };

/**
 * @ecosaude/core/crm: regras do módulo CRM que não dependem de banco nem de tela.
 * Uso: import { JOURNEY_STAGES, noShowRisk, detectIntent } from "@ecosaude/core/crm";
 */
export * from "./constants";
export * from "./messages";
export * from "./scheduling";
export * from "./time";
export * from "./duplicates";

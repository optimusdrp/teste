/**
 * Esquema do módulo CRM (ambiente da clínica).
 *
 * ISOLAMENTO ENTRE CLÍNICAS
 * Toda tabela tem `clinic_id`. Além do filtro no código, o PostgreSQL aplica
 * Row-Level Security (migração 0005): o app da clínica acessa os dados com o
 * papel "ecosaude_tenant" e só enxerga as linhas da clínica da sessão.
 * O `clinic_id` tem como padrão a clínica da sessão (app.clinic_id), então
 * nem é preciso informá-lo nos inserts feitos pelo app.
 *
 * PREPARO PARA O MODO OFFLINE
 * - IDs em UUID podem ser gerados no aparelho (sem depender do servidor)
 * - `client_id` em mensagens e eventos: reenviar a mesma ação não duplica
 * - `version` em contatos e consultas: detecta edição simultânea (conflito)
 */
import {
  APPOINTMENT_STATUSES,
  CHANNEL_MODES,
  CHANNELS,
  CLINIC_ROLES,
  CONVERSATION_STATUSES,
  JOURNEY_STAGES,
  MESSAGE_DIRECTIONS,
  MESSAGE_STATUSES,
  WAITLIST_PERIODS,
} from "@ecosaude/core/crm";
import { relations, sql } from "drizzle-orm";
import {
  boolean,
  date,
  index,
  inet,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { clinics } from "./schema";

/* --------------------------------- Enums ---------------------------------- */

export const channelEnum = pgEnum("channel", CHANNELS);
export const channelModeEnum = pgEnum("channel_mode", CHANNEL_MODES);
export const journeyStageEnum = pgEnum("journey_stage", JOURNEY_STAGES);
export const appointmentStatusEnum = pgEnum("appointment_status", APPOINTMENT_STATUSES);
export const conversationStatusEnum = pgEnum("conversation_status", CONVERSATION_STATUSES);
export const messageDirectionEnum = pgEnum("message_direction", MESSAGE_DIRECTIONS);
export const messageStatusEnum = pgEnum("message_status", MESSAGE_STATUSES);
export const clinicRoleEnum = pgEnum("clinic_role", CLINIC_ROLES);
export const waitlistPeriodEnum = pgEnum("waitlist_period", WAITLIST_PERIODS);
export const waitlistStatusEnum = pgEnum("waitlist_status", ["aguardando", "oferecido", "agendado", "removido"]);
export const offerStatusEnum = pgEnum("offer_status", ["aberta", "preenchida", "expirada", "cancelada"]);

/* -------------------------------- Auxiliares ------------------------------- */

/** Coluna da clínica: obrigatória, com padrão = clínica da sessão atual. */
const clinicId = () =>
  uuid("clinic_id")
    .notNull()
    .default(sql`nullif(current_setting('app.clinic_id', true), '')::uuid`)
    .references(() => clinics.id, { onDelete: "cascade" });

const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () =>
  timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date());

/* ------------------------------ Usuários da clínica ------------------------ */

export const clinicUsers = pgTable(
  "clinic_users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    name: text("name").notNull(),
    email: text("email").notNull(),
    passwordHash: text("password_hash").notNull(),
    role: clinicRoleEnum("role").notNull(),
    active: boolean("active").notNull().default(true),
    mustChangePassword: boolean("must_change_password").notNull().default(true),
    totpSecretEnc: text("totp_secret_enc"),
    totpEnabled: boolean("totp_enabled").notNull().default(false),
    totpLastStep: integer("totp_last_step"),
    failedLogins: integer("failed_logins").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  // E-mail único em TODAS as clínicas: o login descobre a clínica pelo e-mail
  (t) => [uniqueIndex("clinic_users_email_unique").on(sql`lower(${t.email})`), index("clinic_users_clinic_idx").on(t.clinicId)],
);

/** Sessões dos usuários da clínica (mesmo modelo do backoffice: só o hash do token). */
export const clinicSessions = pgTable(
  "clinic_sessions",
  {
    id: text("id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => clinicUsers.id, { onDelete: "cascade" }),
    clinicId: uuid("clinic_id")
      .notNull()
      .references(() => clinics.id, { onDelete: "cascade" }),
    twoFactorPassed: boolean("two_factor_passed").notNull().default(false),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    ip: inet("ip"),
    userAgent: text("user_agent"),
    createdAt: createdAt(),
  },
  (t) => [index("clinic_sessions_user_idx").on(t.userId)],
);

/* ------------------------------- Profissionais ----------------------------- */

export const professionals = pgTable(
  "professionals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    name: text("name").notNull(),
    specialty: text("specialty"),
    /** Cor da coluna na agenda (token da paleta: crm, erp, pep, bi) */
    color: text("color").notNull().default("crm"),
    userId: uuid("user_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    slotMinutes: integer("slot_minutes").notNull().default(30),
    workStart: text("work_start").notNull().default("08:00"),
    workEnd: text("work_end").notNull().default("18:00"),
    breakStart: text("break_start").default("12:00"),
    breakEnd: text("break_end").default("13:00"),
    /** 0 = domingo ... 6 = sábado */
    workDays: integer("work_days").array().notNull().default(sql`'{1,2,3,4,5}'`),
    active: boolean("active").notNull().default(true),
    createdAt: createdAt(),
  },
  (t) => [index("professionals_clinic_idx").on(t.clinicId)],
);

/* --------------------------------- Contatos -------------------------------- */

/**
 * Pessoa que fala com a clínica: começa como contato novo (lead) e segue
 * a jornada até paciente. Uma só ficha, do primeiro "oi" ao retorno anual.
 */
export const contacts = pgTable(
  "contacts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    name: text("name").notNull(),
    /** Somente números, com DDI (ex.: 5551999990000) */
    phone: text("phone"),
    email: text("email"),
    birthDate: date("birth_date"),
    stage: journeyStageEnum("stage").notNull().default("novo"),
    stageChangedAt: timestamp("stage_changed_at", { withTimezone: true }).notNull().defaultNow(),
    lostReason: text("lost_reason"),
    /** Origem: whatsapp, instagram, indicação, google... */
    source: text("source"),
    tags: text("tags").array().notNull().default(sql`'{}'`),
    ownerId: uuid("owner_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    preferredChannel: channelEnum("preferred_channel"),
    /** Consentimento LGPD para mensagens de relacionamento (retornos, campanhas) */
    consentMarketing: boolean("consent_marketing").notNull().default(false),
    consentAt: timestamp("consent_at", { withTimezone: true }),
    /** Pediu para não receber mensagens (SAIR) */
    optedOutAt: timestamp("opted_out_at", { withTimezone: true }),
    lastInteractionAt: timestamp("last_interaction_at", { withTimezone: true }),
    lastVisitAt: timestamp("last_visit_at", { withTimezone: true }),
    /** Controle de edição simultânea (sobe 1 a cada alteração) */
    version: integer("version").notNull().default(1),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("contacts_clinic_stage_idx").on(t.clinicId, t.stage),
    index("contacts_clinic_phone_idx").on(t.clinicId, t.phone),
  ],
);

/** Como encontrar a mesma pessoa em cada canal (telefone, @usuário, id da página). */
export const contactIdentities = pgTable(
  "contact_identities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    channel: channelEnum("channel").notNull(),
    externalId: text("external_id").notNull(),
    displayName: text("display_name"),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("contact_identities_unique").on(t.clinicId, t.channel, t.externalId)],
);

/* -------------------------------- Conversas -------------------------------- */

export const conversations = pgTable(
  "conversations",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    channel: channelEnum("channel").notNull(),
    status: conversationStatusEnum("status").notNull().default("aberta"),
    assigneeId: uuid("assignee_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    unreadCount: integer("unread_count").notNull().default(0),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
    lastMessagePreview: text("last_message_preview"),
    /**
     * Para quem responder: o identificador (telefone/@/id) de quem escreveu por
     * último nesta conversa. Importante quando o paciente tem dois números.
     * Só é usado enquanto ainda for uma identidade deste paciente.
     */
    replyTo: text("reply_to"),
    /** Última mensagem do paciente: define a janela de 24h dos canais da Meta */
    lastInboundAt: timestamp("last_inbound_at", { withTimezone: true }),
    /** Desde quando o paciente espera resposta (null = ninguém esperando) */
    awaitingReplySince: timestamp("awaiting_reply_since", { withTimezone: true }),
    snoozedUntil: timestamp("snoozed_until", { withTimezone: true }),
    /** Última intenção detectada (agendar, remarcar...) */
    intent: text("intent"),
    urgent: boolean("urgent").notNull().default(false),
    urgentKind: text("urgent_kind"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    // Uma conversa por pessoa e canal: o histórico fica contínuo
    uniqueIndex("conversations_contact_channel_unique").on(t.clinicId, t.contactId, t.channel),
    index("conversations_inbox_idx").on(t.clinicId, t.status, t.lastMessageAt),
  ],
);

export const messages = pgTable(
  "messages",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    conversationId: uuid("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    channel: channelEnum("channel").notNull(),
    /** in = paciente, out = clínica, note = nota interna, system = aviso automático */
    direction: messageDirectionEnum("direction").notNull(),
    body: text("body").notNull(),
    status: messageStatusEnum("status").notNull(),
    authorId: uuid("author_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    /** ID da mensagem no canal (WhatsApp, Telegram...): impede gravar a mesma duas vezes */
    externalId: text("external_id"),
    /** ID gerado no aparelho de quem enviou: impede duplicar ao reenviar (offline) */
    clientId: uuid("client_id"),
    /** Modelo usado (necessário fora da janela de 24h) */
    templateKey: text("template_key"),
    /** Dados de automação, ex.: { kind: "waitlist_offer", offerId } */
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    error: text("error"),
    createdAt: createdAt(),
    sentAt: timestamp("sent_at", { withTimezone: true }),
  },
  (t) => [
    index("messages_conversation_idx").on(t.conversationId, t.createdAt),
    uniqueIndex("messages_external_unique").on(t.clinicId, t.channel, t.externalId).where(sql`${t.externalId} is not null`),
    uniqueIndex("messages_client_unique").on(t.clinicId, t.clientId).where(sql`${t.clientId} is not null`),
    index("messages_queue_idx").on(t.status).where(sql`${t.status} = 'fila'`),
  ],
);

/* ---------------------------------- Agenda --------------------------------- */

export const appointments = pgTable(
  "appointments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    professionalId: uuid("professional_id")
      .notNull()
      .references(() => professionals.id, { onDelete: "restrict" }),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    status: appointmentStatusEnum("status").notNull().default("agendado"),
    service: text("service"),
    notes: text("notes"),
    /** recepcao, conversa, lista_espera */
    source: text("source").notNull().default("recepcao"),
    confirmationRequestedAt: timestamp("confirmation_requested_at", { withTimezone: true }),
    confirmedAt: timestamp("confirmed_at", { withTimezone: true }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
    cancelReason: text("cancel_reason"),
    npsRequestedAt: timestamp("nps_requested_at", { withTimezone: true }),
    createdBy: uuid("created_by").references(() => clinicUsers.id, { onDelete: "set null" }),
    version: integer("version").notNull().default(1),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    index("appointments_clinic_start_idx").on(t.clinicId, t.startsAt),
    index("appointments_contact_idx").on(t.contactId),
    // + restrição de "sem horário duplicado" por profissional (migração 0005, extensão btree_gist)
  ],
);

export const waitlistEntries = pgTable(
  "waitlist_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    /** null = qualquer profissional */
    professionalId: uuid("professional_id").references(() => professionals.id, { onDelete: "set null" }),
    period: waitlistPeriodEnum("period").notNull().default("qualquer"),
    notes: text("notes"),
    status: waitlistStatusEnum("status").notNull().default("aguardando"),
    createdAt: createdAt(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [index("waitlist_clinic_status_idx").on(t.clinicId, t.status)],
);

/** Horário liberado (cancelamento) oferecido à lista de espera. Quem responder SIM primeiro fica com ele. */
export const slotOffers = pgTable("slot_offers", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: clinicId(),
  professionalId: uuid("professional_id")
    .notNull()
    .references(() => professionals.id, { onDelete: "cascade" }),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
  status: offerStatusEnum("status").notNull().default("aberta"),
  originAppointmentId: uuid("origin_appointment_id").references(() => appointments.id, { onDelete: "set null" }),
  filledAppointmentId: uuid("filled_appointment_id").references(() => appointments.id, { onDelete: "set null" }),
  filledByContactId: uuid("filled_by_contact_id").references(() => contacts.id, { onDelete: "set null" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdBy: uuid("created_by").references(() => clinicUsers.id, { onDelete: "set null" }),
  createdAt: createdAt(),
});

export const slotOfferCandidates = pgTable(
  "slot_offer_candidates",
  {
    offerId: uuid("offer_id")
      .notNull()
      .references(() => slotOffers.id, { onDelete: "cascade" }),
    waitlistEntryId: uuid("waitlist_entry_id")
      .notNull()
      .references(() => waitlistEntries.id, { onDelete: "cascade" }),
    clinicId: clinicId(),
    contactId: uuid("contact_id")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    /** enviada, aceitou, recusou, atrasado (respondeu depois de preenchida) */
    outcome: text("outcome").notNull().default("enviada"),
    respondedAt: timestamp("responded_at", { withTimezone: true }),
  },
  (t) => [primaryKey({ columns: [t.offerId, t.waitlistEntryId] })],
);

/* ------------------------- Relacionamento e rotina -------------------------- */

export const tasks = pgTable(
  "tasks",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "cascade" }),
    title: text("title").notNull(),
    dueDate: date("due_date").notNull(),
    doneAt: timestamp("done_at", { withTimezone: true }),
    assigneeId: uuid("assignee_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    /** manual, nps_baixo, retorno... */
    kind: text("kind").notNull().default("manual"),
    createdBy: uuid("created_by").references(() => clinicUsers.id, { onDelete: "set null" }),
    createdAt: createdAt(),
  },
  (t) => [index("tasks_clinic_due_idx").on(t.clinicId, t.dueDate)],
);

/** Respostas rápidas: digite /atalho na conversa. */
export const quickReplies = pgTable(
  "quick_replies",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    shortcut: text("shortcut").notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    /** Representa um modelo aprovado pela Meta: pode ser enviado fora da janela de 24h */
    approvedTemplate: boolean("approved_template").notNull().default(false),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("quick_replies_shortcut_unique").on(t.clinicId, t.shortcut)],
);

/** Protocolos de retorno: "revisão em 180 dias", "retorno de 30 dias após consulta"... */
export const returnProtocols = pgTable("return_protocols", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: clinicId(),
  name: text("name").notNull(),
  /** Parte do nome do serviço da consulta (vazio = qualquer consulta) */
  serviceMatch: text("service_match"),
  daysAfter: integer("days_after").notNull(),
  message: text("message").notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: createdAt(),
});

export const npsResponses = pgTable("nps_responses", {
  id: uuid("id").primaryKey().defaultRandom(),
  clinicId: clinicId(),
  contactId: uuid("contact_id")
    .notNull()
    .references(() => contacts.id, { onDelete: "cascade" }),
  appointmentId: uuid("appointment_id").references(() => appointments.id, { onDelete: "set null" }),
  score: integer("score").notNull(),
  createdAt: createdAt(),
});

/**
 * Linha do tempo e trilha de ações do CRM: mudança de etapa, anotações,
 * status de consulta, lembretes enviados...
 */
export const crmEvents = pgTable(
  "crm_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    contactId: uuid("contact_id").references(() => contacts.id, { onDelete: "cascade" }),
    actorId: uuid("actor_id").references(() => clinicUsers.id, { onDelete: "set null" }),
    type: text("type").notNull(),
    data: jsonb("data").$type<Record<string, unknown>>(),
    clientId: uuid("client_id"),
    createdAt: createdAt(),
  },
  (t) => [
    index("crm_events_contact_idx").on(t.clinicId, t.contactId, t.createdAt),
    uniqueIndex("crm_events_client_unique").on(t.clinicId, t.clientId).where(sql`${t.clientId} is not null`),
  ],
);

/**
 * Pares marcados como "não é a mesma pessoa" (ex.: mãe e filho com o mesmo
 * celular). Não voltam a aparecer na lista de possíveis duplicados.
 * Sempre gravado com contact_a < contact_b, para o par ser único.
 */
export const contactDuplicateDismissals = pgTable(
  "contact_duplicate_dismissals",
  {
    clinicId: clinicId(),
    contactA: uuid("contact_a")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    contactB: uuid("contact_b")
      .notNull()
      .references(() => contacts.id, { onDelete: "cascade" }),
    createdBy: uuid("created_by").references(() => clinicUsers.id, { onDelete: "set null" }),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.contactA, t.contactB] })],
);

/**
 * Preferências do CRM da clínica (uma linha por clínica).
 * Confirmação automática: a rotina agendada envia o pedido de confirmação
 * das consultas de daqui a N dias, a partir de um horário do dia.
 */
export const crmSettings = pgTable("crm_settings", {
  clinicId: clinicId().primaryKey(),
  autoConfirm: boolean("auto_confirm").notNull().default(true),
  /** Hora local (fuso da clínica) a partir da qual o envio do dia acontece, 0 a 23 */
  confirmHour: integer("confirm_hour").notNull().default(10),
  /** Consultas de quantos dias à frente (1 = amanhã) */
  confirmDaysBefore: integer("confirm_days_before").notNull().default(1),
  /** Último dia (AAAA-MM-DD, fuso da clínica) em que a rotina já enviou: evita repetir */
  lastAutoConfirmOn: date("last_auto_confirm_on"),
  updatedAt: updatedAt(),
});

/** Canais da clínica: modo simulação hoje, real quando houver credenciais. */
export const channelConnections = pgTable(
  "channel_connections",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    clinicId: clinicId(),
    channel: channelEnum("channel").notNull(),
    mode: channelModeEnum("mode").notNull().default("simulacao"),
    active: boolean("active").notNull().default(true),
    /** Nome exibido: número do WhatsApp, @ do bot, nome da página */
    displayName: text("display_name"),
    /**
     * Identificador da conta no provedor (phone_number_id da Meta, id da página,
     * nome do bot). É por ele que o webhook descobre de qual clínica é a mensagem.
     * Os SEGREDOS (tokens) nunca ficam aqui: vão para variáveis de ambiente
     * ou cofre de segredos (AWS Secrets Manager).
     */
    externalAccountId: text("external_account_id"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    uniqueIndex("channel_connections_unique").on(t.clinicId, t.channel),
    uniqueIndex("channel_connections_account_unique")
      .on(t.channel, t.externalAccountId)
      .where(sql`${t.externalAccountId} is not null`),
  ],
);

/* -------------------------------- Relações --------------------------------- */

export const clinicUsersRelations = relations(clinicUsers, ({ one, many }) => ({
  clinic: one(clinics, { fields: [clinicUsers.clinicId], references: [clinics.id] }),
  sessions: many(clinicSessions),
}));

export const clinicSessionsRelations = relations(clinicSessions, ({ one }) => ({
  user: one(clinicUsers, { fields: [clinicSessions.userId], references: [clinicUsers.id] }),
}));

export const professionalsRelations = relations(professionals, ({ one, many }) => ({
  user: one(clinicUsers, { fields: [professionals.userId], references: [clinicUsers.id] }),
  appointments: many(appointments),
}));

export const contactsRelations = relations(contacts, ({ one, many }) => ({
  owner: one(clinicUsers, { fields: [contacts.ownerId], references: [clinicUsers.id] }),
  identities: many(contactIdentities),
  conversations: many(conversations),
  appointments: many(appointments),
  events: many(crmEvents),
  tasks: many(tasks),
  waitlist: many(waitlistEntries),
}));

export const contactIdentitiesRelations = relations(contactIdentities, ({ one }) => ({
  contact: one(contacts, { fields: [contactIdentities.contactId], references: [contacts.id] }),
}));

export const conversationsRelations = relations(conversations, ({ one, many }) => ({
  contact: one(contacts, { fields: [conversations.contactId], references: [contacts.id] }),
  assignee: one(clinicUsers, { fields: [conversations.assigneeId], references: [clinicUsers.id] }),
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  conversation: one(conversations, { fields: [messages.conversationId], references: [conversations.id] }),
  author: one(clinicUsers, { fields: [messages.authorId], references: [clinicUsers.id] }),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  contact: one(contacts, { fields: [appointments.contactId], references: [contacts.id] }),
  professional: one(professionals, { fields: [appointments.professionalId], references: [professionals.id] }),
}));

export const waitlistEntriesRelations = relations(waitlistEntries, ({ one }) => ({
  contact: one(contacts, { fields: [waitlistEntries.contactId], references: [contacts.id] }),
  professional: one(professionals, { fields: [waitlistEntries.professionalId], references: [professionals.id] }),
}));

export const slotOffersRelations = relations(slotOffers, ({ one, many }) => ({
  professional: one(professionals, { fields: [slotOffers.professionalId], references: [professionals.id] }),
  candidates: many(slotOfferCandidates),
  filledBy: one(contacts, { fields: [slotOffers.filledByContactId], references: [contacts.id] }),
}));

export const slotOfferCandidatesRelations = relations(slotOfferCandidates, ({ one }) => ({
  offer: one(slotOffers, { fields: [slotOfferCandidates.offerId], references: [slotOffers.id] }),
  contact: one(contacts, { fields: [slotOfferCandidates.contactId], references: [contacts.id] }),
  entry: one(waitlistEntries, { fields: [slotOfferCandidates.waitlistEntryId], references: [waitlistEntries.id] }),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  contact: one(contacts, { fields: [tasks.contactId], references: [contacts.id] }),
  assignee: one(clinicUsers, { fields: [tasks.assigneeId], references: [clinicUsers.id] }),
}));

export const crmEventsRelations = relations(crmEvents, ({ one }) => ({
  contact: one(contacts, { fields: [crmEvents.contactId], references: [contacts.id] }),
  actor: one(clinicUsers, { fields: [crmEvents.actorId], references: [clinicUsers.id] }),
}));

export const npsResponsesRelations = relations(npsResponses, ({ one }) => ({
  contact: one(contacts, { fields: [npsResponses.contactId], references: [contacts.id] }),
}));

/**
 * Telegram (Bot API).
 *
 * Pronto para uso real: leitura do Update, verificação do cabeçalho secreto
 * e envio via sendMessage. Para ligar: criar o bot no @BotFather, guardar o
 * token em TELEGRAM_BOT_TOKEN e registrar o webhook com setWebhook
 * (passando secret_token = TELEGRAM_WEBHOOK_SECRET).
 *
 * Ainda NÃO testado contra a API real.
 */
import { timingSafeEqual } from "node:crypto";
import { ChannelError, type ChannelAdapter, type ChannelCredentials, type FetchLike, type WebhookResult } from "./types";

type Json = Record<string, unknown>;
const obj = (v: unknown): Json => (v && typeof v === "object" ? (v as Json) : {});
const str = (v: unknown): string | undefined => (typeof v === "string" ? v : typeof v === "number" ? String(v) : undefined);

/** O Telegram envia o segredo combinado no cabeçalho X-Telegram-Bot-Api-Secret-Token. */
export function verifyTelegramSecret(headerValue: string | null, secret: string): boolean {
  if (!headerValue || !secret) return false;
  const a = Buffer.from(headerValue);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Converte um Update do Telegram. `accountId` = nome do bot (vem da URL do webhook). */
export function parseTelegramUpdate(body: unknown, accountId: string | null = null): WebhookResult {
  const result: WebhookResult = { messages: [], statuses: [] };
  const message = obj(obj(body).message);
  const chatId = str(obj(message.chat).id);
  const messageId = str(message.message_id);
  if (!chatId || !messageId) return result;

  const from = obj(message.from);
  const name = [str(from.first_name), str(from.last_name)].filter(Boolean).join(" ") || str(from.username);
  const text = str(message.text) ?? str(message.caption) ?? (message.photo ? "[imagem]" : message.voice ? "[áudio]" : message.document ? "[documento]" : "[mensagem]");

  result.messages.push({
    channel: "telegram",
    accountId,
    // message_id só é único dentro do chat: combinamos os dois
    externalMessageId: `${chatId}:${messageId}`,
    from: { externalId: chatId, name },
    text,
    receivedAt: new Date(Number(str(message.date) ?? Date.now() / 1000) * 1000),
  });
  return result;
}

export function createTelegramAdapter(creds: ChannelCredentials, fetchFn: FetchLike = fetch as unknown as FetchLike): ChannelAdapter {
  return {
    channel: "telegram",
    mode: "real",
    parseWebhook: (body) => parseTelegramUpdate(body, creds.accountId ?? null),
    async send(message) {
      if (!creds.botToken) throw new ChannelError("Credenciais ausentes para Telegram: botToken", false);
      const res = await fetchFn(`https://api.telegram.org/bot${creds.botToken}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: message.to, text: message.text }),
      });
      const data = obj(await res.json().catch(() => ({})));
      if (!res.ok || data.ok !== true) {
        throw new ChannelError(`Telegram recusou o envio: ${str(data.description) ?? `HTTP ${res.status}`}`, res.status === 429 || res.status >= 500);
      }
      const id = str(obj(data.result).message_id);
      return { externalMessageId: `${message.to}:${id ?? Date.now()}` };
    },
  };
}

/** Update de exemplo no formato oficial (usado pelo simulador e pelos testes). */
export function sampleTelegramUpdate(p: { chatId: string; name?: string; text: string; messageId: number; at: Date }) {
  const [first, ...rest] = (p.name ?? p.chatId).split(" ");
  return {
    update_id: p.messageId,
    message: {
      message_id: p.messageId,
      from: { id: p.chatId, is_bot: false, first_name: first, last_name: rest.join(" ") || undefined },
      chat: { id: p.chatId, type: "private" },
      date: Math.floor(p.at.getTime() / 1000),
      text: p.text,
    },
  };
}

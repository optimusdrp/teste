/**
 * Contrato único entre o CRM e os canais de mensagem.
 *
 * O CRM nunca fala "WhatsApp" ou "Telegram" diretamente: ele fala com um
 * ChannelAdapter. Trocar a simulação pela integração real é trocar o
 * adaptador, sem mexer em telas nem em regras do CRM.
 *
 *   Paciente -> provedor (Meta/Telegram) -> webhook -> parseWebhook() -> InboundMessage -> CRM
 *   CRM -> OutboundMessage -> send() -> provedor -> paciente
 */
import type { Channel, ChannelMode } from "@ecosaude/core/crm";

export type { Channel, ChannelMode };

/** Mensagem recebida, já no formato do CRM (igual para todos os canais). */
export interface InboundMessage {
  channel: Channel;
  /** Conta da clínica que recebeu (phone_number_id, id da página, nome do bot). Define a clínica. */
  accountId: string | null;
  /** ID da mensagem no provedor: usado para não gravar a mesma mensagem duas vezes */
  externalMessageId: string;
  from: {
    /** Telefone (WhatsApp), id do chat (Telegram), id do usuário (Instagram/Messenger) */
    externalId: string;
    name?: string;
    phone?: string;
  };
  text: string;
  receivedAt: Date;
}

/** Atualização de status de uma mensagem que a clínica enviou. */
export interface StatusUpdate {
  channel: Channel;
  externalMessageId: string;
  status: "enviada" | "entregue" | "lida" | "falhou";
  error?: string;
  at: Date;
}

export interface WebhookResult {
  messages: InboundMessage[];
  statuses: StatusUpdate[];
}

/** Modelo aprovado no provedor (obrigatório no WhatsApp fora da janela de 24h). */
export interface TemplateRef {
  name: string;
  language: string;
  variables: string[];
}

export interface OutboundMessage {
  /** Destinatário no canal (mesmo formato de InboundMessage.from.externalId) */
  to: string;
  text: string;
  template?: TemplateRef;
}

export interface SendResult {
  externalMessageId: string;
}

/**
 * Credenciais de cada canal. NUNCA ficam no banco nem no código:
 * vêm de variáveis de ambiente ou de um cofre (AWS Secrets Manager).
 */
export interface ChannelCredentials {
  accessToken?: string;
  /** WhatsApp Cloud API */
  phoneNumberId?: string;
  /** Messenger: id da página; Instagram: id da conta profissional */
  accountId?: string;
  /** Telegram */
  botToken?: string;
  /** Versão da Graph API da Meta, ex.: "v23.0" (confirmar a atual na documentação) */
  graphVersion?: string;
}

/** Função de rede injetável (facilita testes sem internet). */
export type FetchLike = (url: string, init: { method: string; headers: Record<string, string>; body: string }) => Promise<{
  ok: boolean;
  status: number;
  json(): Promise<unknown>;
  text(): Promise<string>;
}>;

export interface ChannelAdapter {
  channel: Channel;
  mode: ChannelMode;
  send(message: OutboundMessage): Promise<SendResult>;
  /** Converte o corpo do webhook do provedor no formato do CRM */
  parseWebhook(body: unknown): WebhookResult;
}

export class ChannelError extends Error {
  constructor(
    message: string,
    readonly retryable: boolean,
  ) {
    super(message);
    this.name = "ChannelError";
  }
}

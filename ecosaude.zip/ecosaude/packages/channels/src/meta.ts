/**
 * Canais da Meta: WhatsApp Cloud API, Messenger e Instagram.
 *
 * O que já está pronto para uso real:
 *  - leitura dos webhooks nos formatos oficiais (mensagens e status)
 *  - verificação da assinatura X-Hub-Signature-256 (HMAC SHA-256 com o App Secret)
 *  - resposta ao desafio de verificação do webhook (hub.challenge)
 *  - envio de texto e de modelo aprovado
 *
 * ATENÇÃO: o envio foi escrito conforme a documentação pública da Graph API,
 * mas ainda NÃO foi testado contra a API real (precisa de conta Meta Business
 * verificada). Antes de ligar em produção, valide com o número de teste da Meta.
 */
import { createHmac, timingSafeEqual } from "node:crypto";
import {
  ChannelError,
  type ChannelAdapter,
  type ChannelCredentials,
  type FetchLike,
  type InboundMessage,
  type OutboundMessage,
  type StatusUpdate,
  type WebhookResult,
} from "./types";

const DEFAULT_GRAPH_VERSION = "v23.0";

/* ------------------------------- Segurança ---------------------------------- */

/**
 * Confere se o webhook veio mesmo da Meta.
 * A Meta assina o corpo BRUTO (exatamente os bytes recebidos) com o App Secret.
 * Compare antes de fazer JSON.parse: um espaço a mais muda a assinatura.
 */
export function verifyMetaSignature(rawBody: string, signatureHeader: string | null, appSecret: string): boolean {
  if (!signatureHeader?.startsWith("sha256=") || !appSecret) return false;
  const expected = createHmac("sha256", appSecret).update(rawBody, "utf8").digest("hex");
  const received = signatureHeader.slice("sha256=".length);
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(received, "hex");
  // timingSafeEqual: comparação em tempo constante (evita ataque por medição de tempo)
  return a.length === b.length && timingSafeEqual(a, b);
}

/**
 * Verificação do webhook (GET) ao cadastrar a URL no painel da Meta.
 * Retorna o "challenge" para responder com status 200, ou null para responder 403.
 */
export function verifyMetaSubscription(params: URLSearchParams, verifyToken: string): string | null {
  const ok = params.get("hub.mode") === "subscribe" && !!verifyToken && params.get("hub.verify_token") === verifyToken;
  return ok ? params.get("hub.challenge") : null;
}

/* ------------------------------- Leitura ------------------------------------ */

type Json = Record<string, unknown>;
const obj = (v: unknown): Json => (v && typeof v === "object" ? (v as Json) : {});
const arr = (v: unknown): unknown[] => (Array.isArray(v) ? v : []);
const str = (v: unknown): string | undefined => (typeof v === "string" ? v : typeof v === "number" ? String(v) : undefined);

/** Mensagens que não são texto viram uma descrição legível para a equipe. */
const MEDIA_LABEL: Record<string, string> = {
  image: "[imagem]",
  audio: "[áudio]",
  video: "[vídeo]",
  document: "[documento]",
  sticker: "[figurinha]",
  location: "[localização]",
  contacts: "[contato]",
};

const WHATSAPP_STATUS: Record<string, StatusUpdate["status"]> = {
  sent: "enviada",
  delivered: "entregue",
  read: "lida",
  failed: "falhou",
};

/** Webhook da WhatsApp Cloud API (object = "whatsapp_business_account"). */
export function parseWhatsAppWebhook(body: unknown): WebhookResult {
  const result: WebhookResult = { messages: [], statuses: [] };
  const root = obj(body);
  if (root.object !== "whatsapp_business_account") return result;

  for (const entry of arr(root.entry)) {
    for (const change of arr(obj(entry).changes)) {
      const value = obj(obj(change).value);
      const accountId = str(obj(value.metadata).phone_number_id) ?? null;
      const names = new Map(arr(value.contacts).map((c) => [str(obj(c).wa_id), str(obj(obj(c).profile).name)]));

      for (const m of arr(value.messages)) {
        const msg = obj(m);
        const type = str(msg.type) ?? "text";
        const from = str(msg.from);
        const id = str(msg.id);
        if (!from || !id) continue;
        let text = MEDIA_LABEL[type] ?? `[${type}]`;
        if (type === "text") text = str(obj(msg.text).body) ?? "";
        if (type === "button") text = str(obj(msg.button).text) ?? text;
        if (type === "interactive") {
          const inter = obj(msg.interactive);
          text = str(obj(inter.button_reply).title) ?? str(obj(inter.list_reply).title) ?? text;
        }
        result.messages.push({
          channel: "whatsapp",
          accountId,
          externalMessageId: id,
          from: { externalId: from, phone: from, name: names.get(from) },
          text,
          receivedAt: new Date(Number(str(msg.timestamp) ?? Date.now() / 1000) * 1000),
        });
      }

      for (const s of arr(value.statuses)) {
        const st = obj(s);
        const status = WHATSAPP_STATUS[str(st.status) ?? ""];
        const id = str(st.id);
        if (!status || !id) continue;
        result.statuses.push({
          channel: "whatsapp",
          externalMessageId: id,
          status,
          error: str(obj(arr(st.errors)[0]).title),
          at: new Date(Number(str(st.timestamp) ?? Date.now() / 1000) * 1000),
        });
      }
    }
  }
  return result;
}

/**
 * Webhook do Messenger (object = "page") e do Instagram (object = "instagram").
 * Os dois usam o mesmo formato "messaging".
 */
export function parseMessagingWebhook(body: unknown, channel: "facebook" | "instagram"): WebhookResult {
  const result: WebhookResult = { messages: [], statuses: [] };
  const root = obj(body);
  const expected = channel === "facebook" ? "page" : "instagram";
  if (root.object !== expected) return result;

  for (const e of arr(root.entry)) {
    const entry = obj(e);
    const accountId = str(entry.id) ?? null;
    for (const ev of arr(entry.messaging)) {
      const event = obj(ev);
      const sender = str(obj(event.sender).id);
      const message = obj(event.message);
      const at = new Date(Number(str(event.timestamp) ?? Date.now()));

      // Mensagens enviadas pela própria página voltam como "echo": ignorar
      if (sender && str(message.mid) && message.is_echo !== true) {
        const attachments = arr(message.attachments);
        const text = str(message.text) ?? (attachments.length ? (MEDIA_LABEL[str(obj(attachments[0]).type) ?? ""] ?? "[anexo]") : "");
        result.messages.push({
          channel,
          accountId,
          externalMessageId: str(message.mid)!,
          from: { externalId: sender },
          text,
          receivedAt: at,
        });
      }

      for (const mid of arr(obj(event.delivery).mids)) {
        const id = str(mid);
        if (id) result.statuses.push({ channel, externalMessageId: id, status: "entregue", at });
      }
    }
  }
  return result;
}

/* -------------------------------- Envio ------------------------------------- */

async function graphPost(fetchFn: FetchLike, url: string, token: string, payload: unknown): Promise<Json> {
  const res = await fetchFn(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = obj(await res.json().catch(() => ({})));
  if (!res.ok) {
    const message = str(obj(data.error).message) ?? `HTTP ${res.status}`;
    // 429 e 5xx: vale tentar de novo depois; 4xx: erro de dados/permissão
    throw new ChannelError(`Meta recusou o envio: ${message}`, res.status === 429 || res.status >= 500);
  }
  return data;
}

function requireCreds(creds: ChannelCredentials, keys: (keyof ChannelCredentials)[], channel: string) {
  const missing = keys.filter((k) => !creds[k]);
  if (missing.length) throw new ChannelError(`Credenciais ausentes para ${channel}: ${missing.join(", ")}`, false);
}

export function createWhatsAppAdapter(creds: ChannelCredentials, fetchFn: FetchLike = fetch as unknown as FetchLike): ChannelAdapter {
  return {
    channel: "whatsapp",
    mode: "real",
    parseWebhook: parseWhatsAppWebhook,
    async send(message: OutboundMessage) {
      requireCreds(creds, ["accessToken", "phoneNumberId"], "WhatsApp");
      const url = `https://graph.facebook.com/${creds.graphVersion ?? DEFAULT_GRAPH_VERSION}/${creds.phoneNumberId}/messages`;
      const payload = message.template
        ? {
            messaging_product: "whatsapp",
            to: message.to,
            type: "template",
            template: {
              name: message.template.name,
              language: { code: message.template.language },
              components: [
                { type: "body", parameters: message.template.variables.map((text) => ({ type: "text", text })) },
              ],
            },
          }
        : { messaging_product: "whatsapp", recipient_type: "individual", to: message.to, type: "text", text: { preview_url: false, body: message.text } };
      const data = await graphPost(fetchFn, url, creds.accessToken!, payload);
      const id = str(obj(arr(data.messages)[0]).id);
      if (!id) throw new ChannelError("WhatsApp não devolveu o ID da mensagem.", true);
      return { externalMessageId: id };
    },
  };
}

/** Messenger e Instagram (Messenger Platform). */
export function createMessagingAdapter(
  channel: "facebook" | "instagram",
  creds: ChannelCredentials,
  fetchFn: FetchLike = fetch as unknown as FetchLike,
): ChannelAdapter {
  return {
    channel,
    mode: "real",
    parseWebhook: (body) => parseMessagingWebhook(body, channel),
    async send(message: OutboundMessage) {
      requireCreds(creds, ["accessToken", "accountId"], channel === "facebook" ? "Messenger" : "Instagram");
      const url = `https://graph.facebook.com/${creds.graphVersion ?? DEFAULT_GRAPH_VERSION}/${creds.accountId}/messages`;
      const data = await graphPost(fetchFn, url, creds.accessToken!, {
        recipient: { id: message.to },
        // RESPONSE = resposta dentro da janela de 24h. Fora dela a Meta exige tags específicas.
        messaging_type: "RESPONSE",
        message: { text: message.text },
      });
      const id = str(data.message_id);
      if (!id) throw new ChannelError("A Meta não devolveu o ID da mensagem.", true);
      return { externalMessageId: id };
    },
  };
}

/* ------------------------ Payloads de exemplo (simulador) ------------------- */

/**
 * Monta um webhook no FORMATO OFICIAL do provedor.
 * O simulador usa isto para que a mensagem simulada passe pelo MESMO
 * parser que vai receber as mensagens reais: se funciona simulado, a leitura
 * do formato real já está validada.
 */
export function sampleWhatsAppPayload(p: { accountId: string; from: string; name?: string; text: string; id: string; at: Date }) {
  return {
    object: "whatsapp_business_account",
    entry: [
      {
        id: "WABA_ID",
        changes: [
          {
            field: "messages",
            value: {
              messaging_product: "whatsapp",
              metadata: { display_phone_number: p.accountId, phone_number_id: p.accountId },
              contacts: [{ profile: { name: p.name ?? p.from }, wa_id: p.from }],
              messages: [{ from: p.from, id: p.id, timestamp: String(Math.floor(p.at.getTime() / 1000)), type: "text", text: { body: p.text } }],
            },
          },
        ],
      },
    ],
  };
}

export function sampleMessagingPayload(
  channel: "facebook" | "instagram",
  p: { accountId: string; from: string; text: string; id: string; at: Date },
) {
  return {
    object: channel === "facebook" ? "page" : "instagram",
    entry: [
      {
        id: p.accountId,
        time: p.at.getTime(),
        messaging: [{ sender: { id: p.from }, recipient: { id: p.accountId }, timestamp: p.at.getTime(), message: { mid: p.id, text: p.text } }],
      },
    ],
  };
}

# EcoSaúde: monorepo

Site público, backoffice interno e ambiente da clínica (CRM hoje; ERP, Prontuário e BI nas
próximas etapas) do ecossistema EcoSaúde.

```
ecosaude/
├── apps/
│   ├── site/          Landing page pública (Next.js)                  -> porta 3000
│   ├── backoffice/    Gestão interna da equipe EcoSaúde (Next.js)     -> porta 3001
│   └── app/           Ambiente da clínica: CRM e, depois, os demais   -> porta 3002
├── packages/
│   ├── core/          Regras do negócio: status, perfis, permissões, validações (zod), regras do CRM
│   ├── db/            PostgreSQL: esquema (Drizzle), migrações, seed, isolamento por clínica (RLS)
│   ├── channels/      WhatsApp, Telegram, Instagram e Messenger: leitura de webhook, envio e simulação
│   ├── auth/          Criptografia e 2FA compartilhadas pelos apps
│   └── tokens/        Cores e fontes compartilhadas (Tailwind v4)
├── docker-compose.yml PostgreSQL local
├── .env.example       Modelo das variáveis de ambiente
└── turbo.json         Orquestra build/lint/typecheck de todos os pacotes
```

**Por que monorepo:** site e backoffice são apps separados (deploy, domínio e acesso isolados),
mas compartilham o mesmo vocabulário de negócio, as mesmas validações e a mesma identidade visual.
Mudou um status em `packages/core`? Os dois apps e o banco acompanham.

---

## 1. Pré-requisitos

| Ferramenta | Versão | Como conferir |
|---|---|---|
| Node.js | 22 ou superior | `node -v` |
| pnpm | 10 | `pnpm -v` (instalar: `npm i -g pnpm`) |
| Docker Desktop | qualquer recente | `docker -v` (só para o banco local) |

## 2. Primeira execução, passo a passo

```bash
# 1. Instale as dependências de todos os pacotes de uma vez
pnpm install

# 2. Crie o arquivo de variáveis a partir do modelo
cp .env.example .env
```

Abra o `.env` e preencha:

- `TOTP_ENCRYPTION_KEY`: gere com o comando abaixo e cole o resultado.
  ```bash
  node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
  ```
- `SEED_ADMIN_PASSWORD`: senha temporária do primeiro administrador (você troca no 1º acesso).

```bash
# 3. Suba o PostgreSQL local (Docker). Ele usa a porta 54320, e não a 5432,
#    para não colidir com um PostgreSQL que já esteja instalado no computador.
pnpm db:up

#    Confira se o projeto está falando com o banco certo:
pnpm db:check

# 4. Crie as tabelas
pnpm db:migrate

# 5. Carregue o catálogo (módulos, funcionalidades, planos) e o administrador
pnpm db:seed
#    Opcional, para testar com dados fictícios (leads, clínica, equipe):
pnpm db:seed -- --demo

# 6. Rode os apps (o "pnpm dev" aplica antes as migrações pendentes, sozinho)
pnpm dev
#    Site:        http://localhost:3000
#    Backoffice:  http://localhost:3001
#    Clínica/CRM: http://localhost:3002
```

> **Atualizou os arquivos do projeto?** Rode `pnpm install` e depois `pnpm dev`: as migrações
> novas são aplicadas automaticamente antes de subir os apps. Se o banco estiver desatualizado
> mesmo assim (ex.: subiu com `turbo` direto), o backoffice e o ambiente da clínica mostram uma
> página "Banco de dados desatualizado" com o passo a passo, em vez de um erro técnico.

### Primeiro acesso ao backoffice

1. Entre com `SEED_ADMIN_EMAIL` e `SEED_ADMIN_PASSWORD`.
2. Crie a sua senha definitiva (mínimo de 12 caracteres, com maiúscula, minúscula e número).
3. Opcional e recomendado: em **Minha conta**, ative a **verificação em duas etapas**
   lendo o QR code com um aplicativo autenticador (Google Authenticator, Microsoft Authenticator...).
   Depois de ativa, o login pede o código do celular após a senha.

Com `--demo`, as contas `comercial@`, `suporte@` e `financeiro@ecosaude.local` usam a senha
`Demo-EcoSaude-2026` e também passam pelo primeiro acesso.

### Primeiro acesso ao CRM (ambiente da clínica, porta 3002)

**Clínica nova:** antes de tudo, em **Ajustes > Clínica**, cadastre os profissionais com os dias,
o expediente e a duração da consulta. É isso que gera os horários livres da agenda.

Com `--demo` existem duas clínicas, para você ver o isolamento entre elas:

| Clínica | Login | Perfil |
|---|---|---|
| Clínica Exemplo | `gestor@clinicaexemplo.com.br` | Gestão (tudo) |
| Clínica Exemplo | `recepcao@clinicaexemplo.com.br` | Recepção |
| Clínica Exemplo | `beatriz@clinicaexemplo.com.br` | Profissional de saúde |
| Clínica Olhar | `gestor@olhar.exemplo.com.br` | Gestão |

Senha de todos: `Demo-EcoSaude-2026` (troca obrigatória no primeiro acesso).

Para uma clínica **real**: no backoffice, abra a clínica, contrate o módulo CRM e, no quadro
**Acessos da clínica**, crie o acesso do gestor. A senha temporária aparece uma vez; o gestor
entra no ambiente da clínica e cadastra a própria equipe em **Ajustes > Equipe**.

## 3. Comandos do dia a dia

| Comando | O que faz |
|---|---|
| `pnpm dev` | Roda site e backoffice juntos |
| `pnpm dev:site` / `pnpm dev:backoffice` / `pnpm dev:app` | Roda só um deles |
| `pnpm --filter @ecosaude/core test` / `pnpm --filter @ecosaude/channels test` | Testes das regras do CRM e da leitura dos canais |
| `pnpm typecheck` / `pnpm lint` / `pnpm build` | Verificações em todos os pacotes |
| `pnpm db:generate` | Gera migração SQL depois de alterar `packages/db/src/schema.ts` |
| `pnpm db:migrate` | Aplica migrações pendentes |
| `pnpm db:studio` | Abre o Drizzle Studio para ver as tabelas no navegador |
| `pnpm db:down` | Para o PostgreSQL local |
| `pnpm db:check` | Testa a conexão e mostra se é o PostgreSQL do Docker ou outro |
| `pnpm db:reset-local` | **Apaga** o banco local e cria de novo (use se a senha do volume não confere) |

### Alterando o banco

1. Edite `packages/db/src/schema.ts` (backoffice/site) ou `packages/db/src/schema-crm.ts` (CRM).
   **Tabela nova do CRM?** Ela precisa de `GRANT` e da política `tenant_isolation` numa migração
   (siga o modelo de `migrations/0005_crm_isolamento.sql`), senão o app da clínica não a enxerga.
2. `pnpm db:generate` (cria um arquivo em `packages/db/migrations`; revise o SQL).
3. `pnpm db:migrate`.
4. Envie o arquivo de migração para o Git junto com o código.

## 4. O que o backoffice faz

| Área | Funções | Quem acessa |
|---|---|---|
| Painel | Leads da semana, funil, clínicas ativas, receita mensal recorrente, testes vencendo | Todos (cada bloco conforme permissão) |
| Leads | Pedidos do site em quadro por etapa (desktop) ou lista (celular), responsável, anotações, motivo de perda, conversão em cliente | Comercial, Admin (Suporte só vê) |
| Clínicas | Cadastro com validação de CNPJ, acesso do gestor ao ambiente da clínica, contratações por módulo, teste gratuito, ativar/suspender/cancelar com motivo, liberar ou bloquear funcionalidades como exceção, acesso efetivo calculado | Comercial, Financeiro, Admin |
| Catálogo | Planos por módulo, preço, limite de usuários, funcionalidades incluídas | Financeiro e Admin editam |
| Equipe | Criar contas (senha temporária exibida uma vez), perfil, desativar conta, redefinir senha, desativar a 2FA de quem perdeu o celular | Admin |
| Minha conta | Ativar/desativar a verificação em duas etapas, trocar senha, ver sessões abertas | Todos |
| Auditoria | Registro permanente de todas as ações, com filtros | Admin, Financeiro |

### Regras garantidas pelo banco (não só pela tela)

- **Uma contratação em aberto por módulo e clínica** (índice único parcial).
- **Auditoria imutável:** um gatilho bloqueia `UPDATE`, `DELETE` e `TRUNCATE` em `audit_log`.
  Por isso membros da equipe são **desativados**, nunca apagados.
- **Preço congelado:** a contratação guarda o preço do momento; mudar o catálogo não altera clientes atuais.
- **Teste sempre com prazo:** contratação em teste exige data de término.

### Segurança

- Senhas com bcrypt (custo 12); comparação em tempo constante mesmo para e-mail inexistente.
- 2FA opcional por usuário (TOTP), ativada em Minha conta; segredo criptografado com AES-256-GCM;
  código não pode ser reutilizado; tolerância de 60 segundos de diferença de relógio.
  Desativar exige a senha; um administrador pode desativar a de quem perdeu o celular.
- Bloqueio de 15 minutos após 5 tentativas erradas (senha ou código).
- Sessões no banco: desativar um usuário ou trocar senha derruba as sessões na hora.
- Cookie `httpOnly`, `sameSite=lax` e `secure` em produção.
- Permissão conferida **em cada ação no servidor**, não só escondendo botões.
- Formulário do site: validação, campo-armadilha, limite de 5 envios por IP por hora e
  deduplicação por e-mail em 24 horas.

## 5. O CRM (ambiente da clínica)

Pensado para a rotina da recepção: tudo o que precisa de ação aparece primeiro, e o máximo
possível acontece sozinho.

| Tela | O que faz | Diferenciais |
|---|---|---|
| **Hoje** | Painel do dia personalizável: régua do dia, recepção ao vivo (Chegou/Faltou em um toque), fila de ações com filtros, amanhã, horários livres, aniversariantes e pulso da semana | Relógio ao vivo: "atrasado", "em consulta" e "próximos" mudam sozinhos; modelos Recepção e Gestão; cada pessoa escolhe, ordena e recolhe os quadros. Detalhes em "Hoje" abaixo |
| **Conversas** | Caixa única de WhatsApp, Telegram, Instagram e Messenger: fila por tempo de espera com medidor da meta de 15 min, filtros (esperando, abertas, minhas, sem responsável, adiadas, resolvidas), ações em lote, busca dentro da conversa, rascunhos, painel com abas e atalhos de teclado | Detecta a intenção e sugere respostas; detecta **sinais de urgência** e mostra orientação (SAMU 192, CVV 188) sem responder sozinho; respeita a **janela de 24h da Meta** (contagem regressiva; fora dela só modelos aprovados); `/atalho` para respostas rápidas. Detalhes em "Conversas" abaixo |
| **Agenda** | Quadro interativo com visões **Dia** (coluna por profissional), **Semana** e **Lista**; horas à esquerda; clique no horário livre para agendar; **arraste a consulta para remarcar**; personalização salva no navegador | Impossível marcar dois pacientes no mesmo horário (garantido pelo banco); remarcar mantém o histórico, pede nova confirmação, avisa o paciente e oferece o horário antigo à lista de espera; ao cancelar, idem. Detalhes em "Agenda" abaixo |
| **Lista de espera** | Fila com filtros e visão por profissional, **encaixes possíveis** (horários livres dos próximos 7 dias que já combinam com alguém), ofertas com contagem regressiva e números do mês | Vaga liberada é oferecida a até 3 pessoas compatíveis; **o primeiro "SIM" fica com ela**, sem a recepção ligar para ninguém. Detalhes em "Lista de espera" abaixo |
| **Jornada** | Quadro (ou lista) Novo, Em conversa, Agendado, Paciente, Para reativar, Perdido, com funil de 90 dias, filtros, ações em lote e personalização | A etapa **muda sozinha** (respondeu, agendou, compareceu, 6 meses sem voltar); cartão "esquenta" quando fica parado; motivo obrigatório ao perder, com ranking dos motivos. Detalhes em "Jornada" abaixo |
| **Contatos** | Leads e pacientes num lugar só (paciente = já foi atendido). Busca ao digitar **sem diferenciar acentos**, filtros por tipo, etapa, canal, origem, etiqueta e responsável, **segmentos prontos**, tabela com colunas à escolha ou cartões, ações em lote e exportação em planilha; **possíveis duplicados** e unificação | Ficha 360 com **linha do tempo unificada** (todas as conversas, consultas, anotações e automações), **melhor horário para falar** e tempo de resposta aprendidos das conversas, **exportação LGPD** em um clique. Detalhes em "Contatos" abaixo |
| **Tarefas** | Lembretes da equipe com prazo e **responsável**; minhas / todas / atrasadas / concluídas; editar, excluir, reabrir | Falta gera tarefa "Remarcar" sozinha; satisfação baixa gera tarefa para a gestão |
| **Retornos** | Radar de quem está na hora de voltar (janela de 7 a 60 dias), faixa de vencimentos, prévia da mensagem, envio em lote, aba **Acompanhar** e resultado por protocolo | Envio em lote só para quem autorizou (LGPD) e **mede o resultado**: quantos voltaram a agendar, no geral e por protocolo. Detalhes em "Retornos" abaixo |
| **Ajustes** | Minha conta (senha, 2FA); **Clínica** (profissionais com dias, expediente, intervalo e duração da consulta; confirmação automática); respostas rápidas; equipe (gestor cria acessos); canais | Validação do expediente; aviso de consultas que ficaram fora de um novo horário; não deixa desativar profissional com consultas futuras; modo simulação ou real por canal |

Automações que respondem sozinhas (todas registradas na linha do tempo):

- **Confirmação automática:** todos os dias, a partir do horário escolhido em Ajustes > Clínica (padrão 10h, até as 20h),
  o CRM pede confirmação das consultas de amanhã (ou de 2/3 dias à frente) que ainda não receberam o pedido.
  Quem pediu SAIR não recebe; ninguém recebe duas vezes.
- **Resposta à confirmação:** "1" confirma; "2" avisa o paciente que a equipe vai ajudar a remarcar e deixa a conversa marcada para a recepção (cancelar continua sendo decisão de uma pessoa, e ao cancelar a vaga é oferecida à lista de espera).
- **Lista de espera:** "SIM" agenda; quem responde depois que a vaga foi preenchida recebe aviso educado.
- **Pesquisa de satisfação (0 a 10):** enviada após a consulta; nota 6 ou menos cria tarefa para a gestão.
- **SAIR / VOLTAR:** o paciente deixa de receber mensagens automáticas (LGPD) e pode voltar com VOLTAR.

Falar com quem ainda não escreveu: na ficha (ou no trilho) do paciente, **Enviar mensagem** abre a
conversa pelo canal disponível (WhatsApp pelo celular do cadastro). Como o paciente ainda não escreveu,
a primeira mensagem precisa ser um modelo aprovado (ex.: `/retomar`).

Atalhos: `Ctrl + K` busca qualquer paciente ou tela; clicar num nome abre o **trilho do paciente**
ao lado (pode fixar), sem sair da tela em que você está.

### Contatos

Endereço: `/crm/contatos` (o antigo `/crm/pacientes` redireciona para cá). Filtros na URL, por exemplo
`?tipo=lead&segmento=novos&origem=instagram&ordem=recentes`.

- **Lead x paciente:** paciente é quem já compareceu a ao menos uma consulta; lead é quem ainda não.
  A barra "Leads | Pacientes" do topo mostra a proporção e filtra com um toque.
- **Números da base:** novos em 30 dias, sem consentimento LGPD e aniversariantes do mês (clique filtra).
- **Busca ao digitar** (nome, celular ou e-mail, sem acento; tecla /).
- **Filtros:** etapa (com contagem), segmentos prontos (aniversariantes, novos, com consulta marcada,
  sem contato há 90 dias, faltaram 2+ vezes, sem consentimento, pediram SAIR), canal, origem,
  etiqueta e responsável. Cada filtro ativo vira uma pílula removível.
- **Tabela ou cartões**, densidade e **colunas à escolha** (salvo no navegador); 30, 60 ou 100 por página.
- **Ações em lote:** adicionar/remover etiqueta, definir responsável, mudar etapa (Perdido pede motivo).
- **Ações rápidas na linha:** abrir conversa, agendar, copiar celular, abrir ficha.
- **Exportar planilha (CSV):** só a gestão; até 5.000 linhas do filtro atual ou dos selecionados.
  Abre direto no Excel (separador ";" e acentos). Cada exportação fica registrada (LGPD).

### Hoje

Painel de trabalho do dia (`/hoje`), que se atualiza sozinho a cada 30 segundos.

- **Números do dia:** consultas (com anel de progresso), conversas esperando resposta, confirmações de
  amanhã, horários livres e novos contatos. Cada número leva ao quadro certo ou à tela completa.
- **Régua do dia:** uma linha do tempo por profissional com expediente, intervalo, consultas (cor da
  situação), horários livres tracejados (clique para agendar) e a linha vermelha do agora. No celular
  rola para os lados, com o nome do profissional fixo.
- **Recepção ao vivo:** placar (atendidos, faltas, a chegar), **atrasados** (10 min sem "Chegou") com
  Chegou/Faltou em um toque, quem está **em consulta** e os **próximos** com contagem regressiva e
  dicas (1ª consulta, sem confirmação, risco de falta). Clique abre a consulta completa.
- **Fila de ações:** urgências, quem espera resposta (anel de espera), risco de falta, confirmar amanhã
  em lote, tarefas (atrasadas sinalizadas, "só minhas tarefas") e retornos, com filtros por tipo.
- **Amanhã:** confirmadas, aguardando e sem pedido, com pedido de confirmação em lote.
- **Horários livres hoje:** por profissional, com quantos da lista de espera servem em cada horário.
- **Aniversariantes** e **Pulso da semana** (comparecimento, faltas, novos contatos e satisfação).
- **Personalizar** (salvo neste navegador): modelos **Recepção** e **Gestão**, mostrar/ocultar,
  ordenar, trocar de coluna, recolher quadros e modo compacto.
- Dia sem consultas (domingo, feriado): mostra o próximo dia com consultas.

### Conversas

Endereço: `/crm/conversas` (filtros na URL: `?filtro=sem_dono&canal=whatsapp&ordem=recentes&q=ana`).

- **Fila:** urgências primeiro; depois maior espera ou mais recentes (botão de ordem). No topo, o
  medidor da **meta de 1ª resposta** (15 min): quantas passaram da meta e a espera mais antiga.
- **Filtros:** Esperando, Abertas, Minhas, Sem responsável, Adiadas e Resolvidas, com contagem; canal.
- **Ações em lote:** "Selecionar" e marque várias para assumir, resolver, adiar ou transferir de uma vez.
- **Conversa:** abre já na mensagem mais nova; mensagens seguidas agrupadas; "Novas mensagens" quando
  você está lendo mais acima; copiar texto; **buscar dentro da conversa** com destaque.
- **Adiar** por 1 h, 2 h, 4 h ou 1 dia (volta para a fila sozinha). **Resolver e ir para a próxima.**
- **Rascunhos:** o texto não enviado fica guardado por conversa neste navegador; a lista mostra "Rascunho".
- **Painel com abas:** Assistente (intenção, respostas sugeridas, agenda, janela de 24h com contagem
  regressiva), Paciente (contato, etapa, etiquetas, consentimento, comparecimentos e faltas, outros
  canais) e Histórico (linha do tempo). Em telas menores abre em "Detalhes".
- **Personalizar** (salvo neste navegador): densidade, trecho da mensagem, painel ao lado, ir para a
  próxima ao resolver/adiar, Enter ou Ctrl+Enter para enviar.
- **Atalhos:** J/K (ou ↓/↑) próxima/anterior, / buscar, R responder, E resolver, A assumir, F buscar
  na conversa, P painel, ? ajuda.

### Jornada

Endereço: `/crm/jornada`.

- **Funil dos últimos 90 dias:** chegaram, conversaram, marcaram e compareceram, com o percentual de
  cada degrau sobre o anterior; a maior perda fica destacada. Ao lado, **por que perdemos** (motivos).
- **Filtros:** busca por nome ou etiqueta (sem acento), atalhos (parados, esperando resposta, com
  consulta, sem responsável, meus contatos), canal, origem, responsável e etiqueta.
- **Quadro ou lista** (tecla V): no quadro, arraste entre etapas ou use "Mover para"; cada coluna
  mostra quantos estão parados e pode ser recolhida. A lista é uma tabela ordenável.
- **Cartão:** esperando resposta, próxima consulta, dias na etapa (amarelo/vermelho quando parado),
  responsável, origem e etiquetas; ações rápidas: abrir conversa, agendar, criar tarefa, mover.
- **Desfazer** logo depois de mover um cartão.
- **Selecionar:** mover vários de etapa (Perdido pede o motivo) e definir o responsável de uma vez.
- **Personalizar** (salvo neste navegador): densidade, ordem, campos do cartão, funil e etapas visíveis.
- Carrega os 800 contatos que mudaram de etapa mais recentemente.

### Lista de espera

Endereço: `/crm/espera`.

- **Números:** quantos na fila (e com oferta pendente), espera média, % de ofertas preenchidas e
  tempo médio entre a oferta e o "SIM" (últimos 30 dias).
- **Encaixes possíveis:** horários livres dos próximos 7 dias (sem consulta e sem oferta aberta) que
  combinam com alguém da fila (profissional e período), agrupados por profissional e dia. Clique no
  horário para oferecer: a tela já marca os primeiros da fila (até 3).
- **Fila:** posição, profissional e período desejados, dias na fila (alerta a partir de 14), ofertas
  recusadas, oferta aberta com contagem regressiva e aviso de quem **já tem consulta marcada**.
  Busca, filtros (profissional, período, situação) e visão em fila única ou **por profissional**.
- **Ofertas:** abertas (expiram sozinhas; quem não respondeu volta para a fila) e histórico com o
  resultado de cada pessoa; cancelar oferta.
- **Oferecer um horário** qualquer (escolhendo profissional e horário livre) continua no topo.

### Retornos

Endereço: `/crm/retornos?janela=14` (7, 14, 30 ou 60 dias).

- **Números:** na hora de voltar, lembrados sem agendar, lembretes em 90 dias e % que voltou a agendar
  em até 30 dias.
- **Vencimentos:** atrasados há mais de 30 dias, atrasados, vencem nesta semana e depois (clique filtra).
- **No radar:** busca, ordem (mais atrasados, vencem antes, nome), protocolo (clique no cartão do
  protocolo), mostrar ou esconder quem não pode receber (sem consentimento ou SAIR, com o motivo).
  Os atrasados que podem receber já vêm marcados. **Ver mensagem** mostra a prévia de cada protocolo
  com o nome do paciente antes de enviar.
- **Acompanhar:** quem foi lembrado nos últimos 30 dias e ainda não agendou: respondeu (abre a
  conversa) ou sem resposta (cria a tarefa "ligar" em um clique).
- **Protocolos:** regra, situação, quantos estão no radar, lembretes e % que voltou a agendar.

### Agenda

Endereço: `/crm/agenda?data=AAAA-MM-DD&visao=dia|semana|lista` (e `&consulta=<id>` abre uma consulta direto).

- **Visões:** Dia (uma coluna por profissional), Semana (segunda a domingo, uma coluna por dia; com um
  só profissional visível mostra também o expediente e os horários livres) e Lista (boa para ligar
  confirmando). No celular, a visão Dia vira lista + horários livres em botões.
- **Horas à esquerda**, fixas ao rolar; cabeçalho fixo; linha vermelha do "agora"; fora do expediente
  sombreado e intervalo hachurado; a grade abre já rolada para a hora atual (ou a primeira consulta).
- **Arrastar para remarcar:** solte a consulta em outro horário (ou na coluna de outro profissional).
  Abre a confirmação "Remarcar consulta" com de/para, opção de avisar o paciente e, se cair fora do
  expediente, "marcar mesmo assim". Horário ocupado do mesmo profissional é recusado. O horário que
  ficou livre pode ser oferecido à lista de espera ali mesmo.
- **Horários livres:** passe o mouse e clique em "+ HH:MM" para agendar; quando há gente na lista de
  espera para aquele profissional/período, o horário mostra quantos aguardam.
- **Trilho de ocupação** por profissional (percentual ocupado e horários livres) e **mini calendário**
  do mês com a intensidade de consultas por dia.
- **Destaques:** consultas com risco alto de falta, "sem resposta" à confirmação e **1ª consulta**
  (paciente que nunca compareceu). Clique no resumo para destacar; busca por paciente ou serviço
  (ignora acentos; Enter abre a primeira encontrada).
- **Personalizar** (fica salvo neste navegador): densidade (compacta, média, ampla), cor por situação
  ou por profissional, profissionais visíveis, filtro de situação, mostrar canceladas, mostrar horários
  livres e "só expediente" ou dia inteiro (6h às 22h).
- **Pedir confirmação** de todas as consultas do dia que ainda não receberam o pedido.
- **Imprimir:** sai uma lista limpa do período, sem menus.
- **Atalhos:** ← → (período anterior/próximo), T (hoje), D/S/L (dia, semana, lista), N (nova consulta),
  / (buscar).

### Cadastros duplicados

A mesma pessoa costuma chegar por caminhos diferentes (liga, depois escreve no Instagram, depois no
WhatsApp). O CRM trata isso em três pontos:

1. **Ao cadastrar** (inclusive dentro do agendamento): enquanto você digita nome, celular, e-mail e
   nascimento, aparece quem já parece ser a pessoa, com o motivo ("mesmo celular", "nome muito
   parecido"...), e o botão **Usar este**. O servidor confere de novo: só cadastra se a recepção marcar
   "é outra pessoa" (ex.: mãe e filho com o mesmo celular).
2. **Na ficha:** aviso "Este paciente pode ter outro cadastro", com **Comparar e unificar**.
3. **Contatos > Possíveis duplicados:** varre a clínica e lista os pares suspeitos.

Como a comparação funciona (`packages/core/src/crm/duplicates.ts`, com testes):
- **Suspeita forte:** mesmo celular (com ou sem DDI e 9º dígito), mesmo e-mail, ou nome parecido +
  mesma data de nascimento.
- **Suspeita média:** nome muito parecido, ignorando acentos, "de/da/dos", ordem das palavras,
  iniciais ("Ana L. Reis") e grafias ("Luiza/Luisa", "Thiago/Tiago").

**Unificar** junta tudo no cadastro escolhido como principal: conversas (mesmo canal vira uma só,
com todas as mensagens), consultas, lista de espera (fica o lugar mais antigo na fila), tarefas,
pesquisas e linha do tempo. Dados vazios são completados; etiquetas somam; se qualquer um pediu SAIR,
o unificado continua sem mensagens. Tudo numa transação; não dá para desfazer, por isso há confirmação.
"Não é a mesma pessoa" esconde o par para sempre.

### Outras regras do dia a dia

- **Consulta:** duração própria (marcar, remarcar ou editar); aviso, com "marcar mesmo assim", quando
  o horário está fora do expediente/intervalo ou o paciente já tem consulta no mesmo horário;
  "Chegou/Faltou" só a partir de 30 min antes; desfazer "Chegou" corrige última visita e etapa;
  "Faltou" tira de "Agendado" e cria a tarefa de remarcar; cancelamento pode ser desfeito se o
  horário continuar livre; editar serviço/observações/duração.
- **Troca de celular:** o número antigo deixa de receber mensagens na hora. Respostas vão para o
  número de quem escreveu por último, se ele ainda for do paciente.
- **SAIR / VOLTAR:** o paciente pode voltar a receber mensagens enviando VOLTAR, ou a equipe libera
  na ficha (fica registrado quem liberou).
- **Lista de espera:** editar a entrada sem perder o lugar; cancelar oferta; marcar ou remarcar num
  horário oferecido cancela a oferta; ofertas com menos de 20 min de antecedência são recusadas.
- **Conversas:** busca por nome ou telefone, "carregar mais" e transferência para um colega.
- **Equipe:** editar nome e perfil (a clínica nunca fica sem gestor ativo) e desligar a 2 etapas de
  quem perdeu o celular. Se o único gestor ficar sem acesso, o backoffice gera nova senha ou
  desliga a 2 etapas (na página da clínica).

### Testando os canais sem integração (simulador)

1. Entre como gestor e clique em **Simulador de canais** (canto inferior direito).
2. Escolha o canal, o paciente (ou um número novo) e escreva como se fosse ele. Experimente:
   `Quero marcar uma consulta`, `Quanto custa?`, `1` (confirmar), `SIM` (aceitar vaga), `9` (nota), `SAIR`, `VOLTAR`.
3. A mensagem é montada **no formato oficial** (o mesmo JSON que a Meta/Telegram enviam) e passa
   pelo **mesmo leitor e pelas mesmas regras** da integração real. Ligar o canal real é só trocar
   quem entrega a mensagem.

### Isolamento entre clínicas

Cada operação do app da clínica roda com o papel `ecosaude_tenant` e a clínica da sessão
(`withTenant`). O PostgreSQL só devolve e só aceita linhas daquela clínica (Row-Level Security),
mesmo que um código esqueça o filtro. O backoffice usa o dono das tabelas e enxerga tudo.

### Pronto para o modo offline (próxima etapa)

IDs gerados no aparelho (`client_id`) tornam reenvios seguros (não duplicam), e `version` nos
cadastros e consultas detecta edição simultânea ("alterado por outra pessoa"). A fila de envio
já separa gravar de enviar.

## 6. Ligando os canais de verdade

Segredos ficam **só** nas variáveis de ambiente (Vercel ou AWS Secrets Manager), nunca no banco.
Cada clínica informa em **Ajustes > Canais** o identificador da própria conta (número, página, bot):
é por ele que o webhook descobre de qual clínica é a mensagem. O modo **Real** só fica disponível
quando o servidor tem a credencial do canal.

| Canal | Variáveis | URL do webhook |
|---|---|---|
| WhatsApp (Cloud API) | `WHATSAPP_ACCESS_TOKEN`, `META_APP_SECRET`, `META_VERIFY_TOKEN` | `https://SEU-DOMINIO/api/webhooks/whatsapp` |
| Instagram | `INSTAGRAM_ACCESS_TOKEN`, `META_APP_SECRET`, `META_VERIFY_TOKEN` | `https://SEU-DOMINIO/api/webhooks/instagram` |
| Messenger | `MESSENGER_PAGE_TOKEN`, `META_APP_SECRET`, `META_VERIFY_TOKEN` | `https://SEU-DOMINIO/api/webhooks/facebook` |
| Telegram | `TELEGRAM_BOT_TOKEN`, `TELEGRAM_WEBHOOK_SECRET` | `https://SEU-DOMINIO/api/webhooks/telegram?conta=UsuarioDoBot` |

Passo a passo (Meta):

1. Crie um app tipo **Empresa** em developers.facebook.com e adicione WhatsApp, Messenger e/ou Instagram.
2. Gere um token de **usuário do sistema** (não expira) e coloque nas variáveis acima.
3. Em Webhooks, informe a URL, o `META_VERIFY_TOKEN` e assine o campo `messages`.
   O EcoSaúde confere a assinatura `X-Hub-Signature-256` de cada chamada com o `META_APP_SECRET`.
4. Cadastre e aprove na Meta os **modelos** usados fora da janela de 24h (confirmação, retorno,
   retomada de conversa) e marque as respostas correspondentes como "modelo aprovado".
5. Em Ajustes > Canais, informe o ID da conta e troque o modo para **Real**.

Telegram: crie o bot no @BotFather e registre o webhook com
`https://api.telegram.org/bot<TOKEN>/setWebhook?url=<URL acima>&secret_token=<TELEGRAM_WEBHOOK_SECRET>`.

> **Ponto de atenção para muitas clínicas:** na Meta, o caminho é a EcoSaúde virar
> **Tech Provider** e usar o *Embedded Signup*: um token do app atende os números de todas as
> clínicas (cada uma só informa o seu ID). No Telegram cada clínica tem o próprio bot, então o
> próximo passo é guardar o token **por clínica** num cofre (AWS Secrets Manager), em vez de uma
> única variável de ambiente. Os adaptadores de envio para a Graph API foram escritos conforme a
> documentação, mas ainda não foram testados contra a API real.

### Rotina agendada

`/api/cron/despachar` reenvia mensagens que ficaram na fila, expira ofertas da lista de espera,
move pacientes para "Para reativar" e faz a **confirmação automática**. O `apps/app/vercel.json` agenda a cada 10 minutos e a
rota exige `CRON_SECRET`. No plano Hobby da Vercel o cron roda no máximo uma vez por dia;
para a frequência de 10 minutos é preciso o plano Pro (ou um agendador externo chamando a URL
com `Authorization: Bearer <CRON_SECRET>`). No Hobby, agende a única execução diária para depois
do horário de confirmação da clínica (ex.: `0 14 * * *` = 11h em Brasília), senão a confirmação
automática nunca roda.

Para testar localmente: `curl -H "Authorization: Bearer <CRON_SECRET>" http://localhost:3002/api/cron/despachar`.

## 7. Problemas comuns

| Mensagem | Causa e solução |
|---|---|
| `autenticação do tipo senha falhou para o usuário "postgres"` (ou `password authentication failed`) | Há outro PostgreSQL no computador usando a porta do `DATABASE_URL`, ou o volume do Docker foi criado com outra senha. Confira se o `.env` usa a porta **54320** e rode `pnpm db:check`. Se continuar, `pnpm db:reset-local` (apaga os dados locais). |
| `Nenhum PostgreSQL respondeu` / `ECONNREFUSED` | Docker Desktop fechado ou banco não iniciado: abra o Docker e rode `pnpm db:up`. |
| `Can't find meta/_journal.json` | Versão antiga do `migrate.ts` (caminho com acento no Windows). Atualize para a versão atual. |
| Código da 2FA "não confere" | O relógio do computador ou do celular está fora do horário: ative "Definir horário automaticamente" nos dois. Se reativou a 2FA, apague o cadastro antigo do EcoSaúde no aplicativo e use só o QR code novo. |
| `permission denied to grant role "ecosaude_tenant"` ao migrar | O papel do isolamento foi criado por outro usuário do banco. Como administrador: `GRANT ecosaude_tenant TO <seu_usuario> WITH ADMIN OPTION;` e rode a migração de novo. |
| `column ... does not exist` / página "Banco de dados desatualizado" | O código foi atualizado, mas as migrações novas não foram aplicadas. Pare o servidor, rode `pnpm db:migrate` e suba de novo (o `pnpm dev` já faz isso sozinho). |
| `DeprecationWarning: Calling client.query() when the client is already executing a query` | Várias consultas disparadas ao mesmo tempo (`Promise.all`) dentro de `withTenant`, que usa uma única conexão. Use `inSequence([() => ..., () => ...])` do `@ecosaude/db` dentro de transações; `Promise.all` só com `db` (pool). |
| Agenda vazia, sem horários livres | Nenhum profissional cadastrado ou ativo: Ajustes > Clínica. |
| Confirmação automática não envia | Confira em Ajustes > Clínica se está ligada, se já passou do horário escolhido (e antes das 20h), se o plano inclui "Confirmações" e se a rotina agendada está rodando (`CRON_SECRET` e `vercel.json`). |
| Mensagem "Fora da janela de 24h" ao responder | Regra da Meta: o paciente não escreve há mais de 24h. Use uma resposta rápida marcada como modelo aprovado (ex.: `/retomar`). |
| Caracteres estranhos no terminal (`autentica��o`) | Só a codificação do PowerShell; não afeta o projeto. Para corrigir a exibição: `chcp 65001`. |

## 8. Publicar na Vercel

São **três projetos** na Vercel apontando para o mesmo repositório.

1. **Banco:** crie um PostgreSQL gerenciado (ex.: Neon, pela aba Storage da Vercel), na região
   São Paulo quando disponível. Copie a connection string **com pooling** e `sslmode=require`.
2. **Migrações:** do seu computador, aponte para o banco novo e rode:
   ```bash
   DATABASE_URL="postgres://..." pnpm db:migrate
   DATABASE_URL="postgres://..." SEED_ADMIN_PASSWORD="..." pnpm db:seed
   ```
3. **Projeto do site:** Add New, Project, importe o repositório, Root Directory `apps/site`.
   Variáveis: `DATABASE_URL`, `NEXT_PUBLIC_SITE_URL`.
4. **Projeto do backoffice:** importe o mesmo repositório, Root Directory `apps/backoffice`.
   Variáveis: `DATABASE_URL`, `TOTP_ENCRYPTION_KEY`.
   Recomendado: ativar Deployment Protection e usar um domínio próprio (ex.: `admin.seudominio.com.br`).
5. **Projeto da clínica (CRM):** Root Directory `apps/app`.
   Variáveis: `DATABASE_URL`, `TOTP_ENCRYPTION_KEY`, `CRON_SECRET` e, quando ligar canais reais,
   as variáveis da seção 6. O cron já está em `apps/app/vercel.json`.
6. Em todos, a Vercel detecta pnpm e Turborepo sozinha. Região das funções: `gru1` (São Paulo).

> Neon e outros bancos gerenciados não dão superusuário: a migração `0005` cria o papel
> `ecosaude_tenant` com o próprio usuário do banco (testado com um usuário sem superusuário).

> `TOTP_ENCRYPTION_KEY` precisa ser a MESMA em todos os ambientes que usam o mesmo banco.
> Se ela mudar, as 2FA já ativadas deixam de funcionar e precisam ser redefinidas.

## 9. Ainda não incluído (próximas etapas)

- Aviso por e-mail para a equipe comercial quando chega um lead.
- Rotina agendada para marcar como encerrados os testes vencidos (o **acesso** já é bloqueado
  automaticamente ao vencer; só o status exibido continua "Em teste" até alguém agir).
- Códigos de recuperação da 2FA (hoje, quem perde o celular pede a um administrador para redefinir).
- Integração com provedor de pagamento e emissão de cobrança.
- Fuso horário por clínica: hoje todas usam o horário de Brasília (America/Sao_Paulo). Clínicas
  no AM, MT, MS, RO, RR, AC precisam de um campo de fuso na clínica (próxima etapa).
- CRM antes de produção: recuperação de senha por e-mail (hoje o gestor gera uma senha nova),
  exclusão/anonimização do paciente a pedido (LGPD; a exportação já existe), teste com os canais reais.
- CRM: modo offline (fila local no navegador e sincronização), campanhas segmentadas,
  envio de modelos com variáveis pela API da Meta, anexos (imagem, áudio, PDF) nas conversas,
  assistente com IA (Gemini) para resumir conversas e sugerir respostas.
- Testes de ponta a ponta no repositório (os fluxos foram validados com Playwright durante o
  desenvolvimento; as regras do CRM e a leitura dos canais já têm testes unitários).
